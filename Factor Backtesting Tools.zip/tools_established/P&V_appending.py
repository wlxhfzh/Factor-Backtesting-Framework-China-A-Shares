import pandas as pd
import os
import psutil
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List
import ast


class DataEnricher:
    def __init__(self, base_path: str):
        """
        初始化数据增强器
        :param base_path: 本地数据存储根目录（存放 pickle 文件的目录）
        """
        self.base_path = base_path

    def load_day_data(self, date_str: str, columns: List[str]) -> pd.DataFrame:
        file_path = os.path.join(self.base_path, f"{date_str}.pkl")
        if not os.path.exists(file_path):
            print(f"文件 {file_path} 不存在")
            return pd.DataFrame()
        try:
            df = pd.read_pickle(file_path)
            if not isinstance(df.index, pd.MultiIndex):
                print(f"文件 {file_path} 的索引不是 MultiIndex")
                return pd.DataFrame()
            missing = [col for col in columns if col not in df.columns]
            if missing:
                print(f"文件 {file_path} 缺少列: {missing}")
                return pd.DataFrame()
            return df[columns]
        except Exception as e:
            print(f"读取文件 {file_path} 时出错: {e}")
            return pd.DataFrame()

    def process_row(self, row: pd.Series, columns: List[str]) -> dict:
        """
        处理一行数据，提取该行中所有 securityId 对应的指标数据
        :param row: 包含 'dateTime' 与 'securityId' 的一行数据
        :param columns: 要提取的指标列名列表
        :return: 一个字典，键为各指标，值为列表（每个列表长度与该行中 securityId 数量一致）
        """
        # 处理 dateTime：确保传入 load_day_data 的是单个日期字符串
        date_val = row.get('dateTime', None)
        if date_val is None:
            return {col: [] for col in columns}
        try:
            # 如果 date_val 是列表或其他非字符串类型，取第一个元素
            if isinstance(date_val, list):
                date_val = date_val[0]
            dt = pd.to_datetime(date_val)
            date_str = dt.strftime('%Y-%m-%d')
        except Exception as e:
            print(f"转换 dateTime {date_val} 失败: {e}")
            return {col: [] for col in columns}

        # 处理 securityId：如果 CSV 中以字符串形式存储列表，例如 "['000001.SZ', '000002.SZ']"
        sec_val = row.get('securityId', None)
        if sec_val is None:
            return {col: [] for col in columns}
        if isinstance(sec_val, str):
            sec_val = sec_val.strip()
            if sec_val.startswith('[') and sec_val.endswith(']'):
                try:
                    sec_ids = ast.literal_eval(sec_val)
                    if not isinstance(sec_ids, list):
                        sec_ids = [sec_ids]
                except Exception as e:
                    print(f"解析 securityId 字符串 {sec_val} 失败: {e}")
                    sec_ids = [sec_val]
            else:
                sec_ids = [sec_val]
        elif not isinstance(sec_val, list):
            sec_ids = [sec_val]
        else:
            sec_ids = sec_val

        # 加载当天数据
        day_data = self.load_day_data(date_str, columns)
        result = {col: [] for col in columns}
        # 如果没有数据，则返回所有 securityId 对应的指标均为 None
        if day_data.empty:
            for col in columns:
                result[col] = [None] * len(sec_ids)
            return result

        # 对于每个 securityId，从 day_data 中提取数据
        for sid in sec_ids:
            try:
                # 这里 day_data 的索引为 MultiIndex，第一层为日期，第二层为 securityId
                data = day_data.loc[(date_str, sid)]
                # 如果返回的是 DataFrame（可能存在多行），取第一行
                if isinstance(data, pd.DataFrame):
                    data = data.iloc[0]
                # 如果 data 是 Series，则转换为字典
                if isinstance(data, pd.Series):
                    data_dict = data.to_dict()
                else:
                    data_dict = {}
                for col in columns:
                    result[col].append(data_dict.get(col, None))
            except Exception as e:
                # 如果找不到该 securityId，记录 None
                for col in columns:
                    result[col].append(None)
        return result

    def add_metrics(self, factor_df: pd.DataFrame, columns: List[str], max_workers: int = 4) -> pd.DataFrame:
        """
        为因子数据 DataFrame 添加指标列
        :param factor_df: 待增强的因子 DataFrame（需包含 'dateTime' 和 'securityId' 列）
        :param columns: 要添加的指标列名列表
        :param max_workers: 并发线程数
        :return: 增强后的 DataFrame（原有每行增加的指标列内容为列表或单一数值）
        """
        # 如果指标列不存在，则在 DataFrame 中创建
        for col in columns:
            if col not in factor_df.columns:
                factor_df[col] = None

        results = {}
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(self.process_row, row, columns): idx
                       for idx, row in factor_df.iterrows()}
            for future in tqdm(as_completed(futures), total=len(futures), desc="Processing rows"):
                idx = futures[future]
                try:
                    res = future.result()
                except Exception as e:
                    print(f"处理行 {idx} 出错: {e}")
                    res = {col: [] for col in columns}
                results[idx] = res

        # 更新原始 DataFrame，每个新增列写入对应的结果
        for idx, res in results.items():
            for col in columns:
                val = res.get(col)
                # 如果列表只有一个元素，则将其转换为单一数值
                if isinstance(val, list) and len(val) == 1:
                    factor_df.at[idx, col] = val[0]
                else:
                    factor_df.at[idx, col] = val
        return factor_df

    @staticmethod
    def monitor_memory() -> float:
        """
        监控当前进程内存使用（MB）
        """
        import psutil
        process = psutil.Process(os.getpid())
        return process.memory_info().rss / (1024 ** 2)


if __name__ == '__main__':
    # 修改 base_path 为实际存放 pickle 文件的目录
    base_path = "/Volumes/Elements/hb_data/daily_cbond_quota/"
    enricher = DataEnricher(base_path)

    # 加载因子数据（CSV 文件应包含 dateTime 和 securityId 两列）
    factor_df = pd.read_pickle('/Users/vincent/PycharmProjects/trading_strat/HWBS/factor_cache/CorrPV/follow_coeff_ma/follow_coeff_ma.pkl')
    factor_df = factor_df.copy()[['daily_follow_coeff_ma10']]
    factor_df = factor_df.reset_index()
    factor_df = factor_df.copy().rename(columns={'date': 'dateTime'})
    print(factor_df.head())


    # 指定需要添加的指标列名称（保持原有名称）
    cols = ['preClose', 'open', 'high', 'low', 'close', 'vwap', 'changePct', 'volume', 'amount']

    # 增强因子数据
    enhanced_df = enricher.add_metrics(factor_df, cols, max_workers=4)

    # 保存结果到 pkl 文件
    enhanced_df.to_pickle('/Users/vincent/PycharmProjects/trading_strat/HWBS/factor_cache/CorrPV/follow_coeff_ma/enhanced_data.pkl')
    print(f"内存峰值使用: {enricher.monitor_memory():.2f} MB")