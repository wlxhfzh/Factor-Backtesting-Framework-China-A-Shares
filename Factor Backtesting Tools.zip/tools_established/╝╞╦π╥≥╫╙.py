import pandas as pd
import numpy as np
from tqdm import tqdm

def calc_skewness(series, window=40, min_periods=40):
    """滚动计算总偏度（三阶中心距标准化）"""
    return series.rolling(window, min_periods=min_periods).apply(lambda x: pd.Series(x).skew(), raw=False)

def calc_neg_skewness(series, window=40, min_periods=40):
    """滚动计算负偏度（仅窗口内小于均值部分的三阶中心距标准化）"""
    def neg_skew(x):
        x = pd.Series(x)
        m = x.mean()
        s = x.std()
        neg = x[x < m]
        if len(neg) < 2 or s == 0:
            return np.nan
        return np.mean(((neg - m) / s) ** 3)
    return series.rolling(window, min_periods=min_periods).apply(neg_skew, raw=False)

if __name__ == "__main__":
    # 路径请根据实际修改
    input_path = r'D:\桌面\pycharmprojects\量价.csv'
    output_path_skew = r'D:\桌面\pycharmprojects\factor\csvs\量价_总偏度.csv'
    output_path_neg_skew = r'D:\桌面\pycharmprojects\factor\csvs\量价_负偏度系数.csv'

    print("【1/4】读取原始数据 ...")
    df = pd.read_csv(input_path)
    if 'dateTime' in df.columns:
        df['dateTime'] = pd.to_datetime(df['dateTime'])
        df = df.sort_values(['securityId', 'dateTime']).reset_index(drop=True)
    else:
        raise ValueError('原始数据缺少dateTime列')

    window = 40  # 2个月窗口

    # 计算总偏度
    print("【2/4】计算滚动总偏度 ...")
    skew_list = []
    for sid, subdf in tqdm(df.groupby('securityId'), desc="总偏度"):
        skew = calc_skewness(subdf['changePct'], window=window)
        skew_list.append(skew)
    df_skew = df.copy()
    df_skew['总偏度'] = pd.concat(skew_list).sort_index()

    print("【3/4】保存总偏度 ...")
    df_skew.to_csv(output_path_skew, index=False, encoding='utf_8_sig')
    print(f"已保存：{output_path_skew}")

    # 计算负偏度
    print("【4/4】计算滚动负偏度系数 ...")
    neg_skew_list = []
    for sid, subdf in tqdm(df.groupby('securityId'), desc="负偏度系数"):
        neg_skew = calc_neg_skewness(subdf['changePct'], window=window)
        neg_skew_list.append(neg_skew)
    df_neg_skew = df.copy()
    df_neg_skew['负偏度系数'] = pd.concat(neg_skew_list).sort_index()

    print("【5/5】保存负偏度系数 ...")
    df_neg_skew.to_csv(output_path_neg_skew, index=False, encoding='utf_8_sig')
    print(f"已保存：{output_path_neg_skew}")