import os
import pandas as pd
import numpy as np
from concurrent.futures import ThreadPoolExecutor
import alphalens as al
import psutil
import matplotlib.pyplot as plt
import sys
import os
import gc
import re
from alphalens.performance import mean_return_by_quantile
from alphalens.performance import (factor_information_coefficient,
                                   mean_information_coefficient)
from alphalens.tears import create_turnover_tear_sheet
from alphalens.utils import get_clean_factor_and_forward_returns
from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.shared import Pt
from docx import Document
from docx.shared import Cm
import os


# ---------------------- 内存监控函数 ----------------------
def memory_usage():
    """返回当前 Python 进程内存占用，单位 MB"""
    process = psutil.Process(os.getpid())
    return process.memory_info().rss / 1024 ** 2


# ----------------- ---工具函数（df写入doc用）---------------------
def dataframe_to_word(df, output_path="output.docx", title="数据报告"):
    """将DataFrame转换为Word表格"""
    # 创建文档对象
    # 加载或创建文档
    doc = Document(output_path) if os.path.exists(output_path) else Document()

    # 添加主标题（网页4方案）
    doc.add_heading(title, level=0)

    # 创建表格（网页1+网页3优化）
    table = doc.add_table(rows=df.shape[0] + 1, cols=df.shape[1])

    # 设置表头（网页4样式优化）
    header_cells = table.rows[0].cells
    for col_idx, col_name in enumerate(df.columns):
        header_cells[col_idx].text = str(col_name)
        header_cells[col_idx].paragraphs[0].runs[0].bold = True  # 加粗
        header_cells[col_idx].paragraphs[0].alignment = WD_PARAGRAPH_ALIGNMENT.CENTER  # 居中

    # 填充数据（网页1+网页5优化）
    for row_idx in range(df.shape[0]):
        row_data = df.iloc[row_idx]
        cells = table.rows[row_idx + 1].cells
        for col_idx, value in enumerate(row_data):
            cells[col_idx].text = str(value)
            cells[col_idx].paragraphs[0].alignment = WD_PARAGRAPH_ALIGNMENT.CENTER

    # 动态列宽调整
    for col_idx, column in enumerate(df.columns):
        max_length = max(df[column].astype(str).map(len).max(), len(column))
        table.columns[col_idx].width = Pt(max_length * 7)  # 按字符数动态计算

    # 设置表格边框和背景色
    table.style = 'Medium Shading 1 Accent 1'  # Word内置样式

    # 保存文档
    doc.save(output_path)


def reshape_price_data(df):
    """
    将包含 'dateTime'、'securityId' 和 'close' 三列的 DataFrame 转换为
    行索引为日期、列为股票代码的 DataFrame。

    参数：
      df: 原始 DataFrame，必须包含 'dateTime', 'securityId', 'close' 三列

    返回：
      一个新的 DataFrame，其行索引为 dateTime，列为 securityId，值为 close。
    """
    # 确保 'dateTime' 列为 datetime 类型
    df['dateTime'] = pd.to_datetime(df['dateTime'])

    # 仅保留需要的列
    df_sub = df[['dateTime', 'securityId', 'close']]

    # 利用 pivot 将数据结构转换为：行索引为 dateTime，列为 securityId，值为 close
    price_df = df_sub.pivot(index='dateTime', columns='securityId', values='close')

    return price_df


# ----------------- ---工具函数（手动计算周转率用）---------------------
def calculate_turnover_metrics(clean_factor_data):
    """
    计算因子数据在5日和10日窗口下的换手率指标，并返回一个合并后的 DataFrame。

    输入：
      clean_factor_data：alphanens格式的因子数据，要求索引为 MultiIndex(['dateTime', 'securityId']),
                         并包含 'factor_quantile' 列（代表因子分位）。

    处理流程：
      1. 重置索引并确保 'dateTime' 为 datetime 类型，同时按 ['securityId', 'dateTime'] 排序。
      2. 定义内部函数 calculate_turnover()，根据传入的窗口 window 计算每日换手率，
         具体为：对每只证券，比较今天与 window 天前的 factor_quantile 是否变化（不同记为 1，相同记为 0），
         然后按 dateTime 和 factor_quantile 分组，求该组内变化指标的均值。
      3. 分别计算5D和10D的换手率 DataFrame，再对每个 DataFrame 计算各分位的均值和标准差。
      4. 合并5D和10D的结果，返回包含以下列的数据框：
         - quantile
         - turnover_mean_5D, turnover_std_5D
         - turnover_mean_10D, turnover_std_10D
    """
    # 重置索引，使得 'dateTime' 和 'securityId' 成为普通列
    temp_data = clean_factor_data.reset_index()
    # 确保 'dateTime' 转换为 datetime 类型
    temp_data['date'] = pd.to_datetime(temp_data['date'])
    # 按照 securityId 和 dateTime 排序
    temp_data.sort_values(['asset', 'date'], inplace=True)

    def calculate_turnover(data, window=1):
        """
        计算给定窗口下的换手率：
          对每只证券，比较当前的 factor_quantile 与前 window 天的值是否不同，返回 0/1 序列，
          再按 ['dateTime', 'factor_quantile'] 分组取均值，得到每日该分位的换手率。
        """
        # 计算每只证券的变化标记：如果今天的分位与 window 天前不同，则为1，否则为0
        data['changed'] = data.groupby('asset')['factor_quantile'].transform(
            lambda x: x.ne(x.shift(window)).astype(int)
        )
        # 按日期和分位汇总计算每日换手率
        q_turnover = data.groupby(['date', 'factor_quantile'])['changed'].mean().unstack()
        return q_turnover

    # 计算1日换手率
    one_day_turnover = calculate_turnover(temp_data, window=1)
    # 计算5日换手率
    five_day_turnover = calculate_turnover(temp_data, window=5)
    # 计算10日换手率
    ten_day_turnover = calculate_turnover(temp_data, window=10)

    def aggregate_turnover(q_turnover):
        """
        对换手率 DataFrame（行：日期，列：分位）按日期求均值和标准差，
        得到每个分位的全样本换手率均值和标准差，以便后续合并。
        """
        df_out = pd.DataFrame({
            'turnover_mean': q_turnover.mean(),
            'turnover_std': q_turnover.std()
        })
        df_out = df_out.reset_index()  # 'factor_quantile' 成为一列
        # 重命名分位列名为 'quantile'
        df_out.rename(columns={'factor_quantile': 'quantile'}, inplace=True)
        # 由于 reset_index 后默认索引列名可能就是原列的名称，也可以将 index 重命名
        df_out['quantile'] = df_out.index.astype(str)  # 如果列索引已经丢失，则用 index 表示分位
        return df_out

    # 汇总1D,5D和10D换手率
    one_day_turnover_df = pd.DataFrame({
        'quantile': one_day_turnover.columns.astype(str),
        'turnover_mean_1D': (one_day_turnover.mean() * 100).round(2),
        'turnover_std_1D': (one_day_turnover.std() * 100).round(2)
    }).reset_index(drop=True)

    five_day_turnover_df = pd.DataFrame({
        'quantile': five_day_turnover.columns.astype(str),
        'turnover_mean_5D': (five_day_turnover.mean() * 100).round(2),
        'turnover_std_5D': (five_day_turnover.std() * 100).round(2)
    }).reset_index(drop=True)

    ten_day_turnover_df = pd.DataFrame({
        'quantile': ten_day_turnover.columns.astype(str),
        'turnover_mean_10D': (ten_day_turnover.mean() * 100).round(2),
        'turnover_std_10D': (ten_day_turnover.std() * 100).round(2)
    }).reset_index(drop=True)

    # 合并1D,5D和10D的结果
    merged_df = pd.merge(one_day_turnover_df, five_day_turnover_df, on='quantile', how='outer')
    combined_df = pd.merge(merged_df, ten_day_turnover_df, on='quantile', how='outer')
    return combined_df


# ---------------------- 因子数据处理函数 ----------------------
def process_factor_data(factor_file_path):
    """
    读取因子数据并转换成 alphalens 可用的 MultiIndex Series。
    假设原始 CSV 包含 'date', 'securityId', 'factor' 三列。
    """
    factor_df = pd.read_csv(factor_file_path)
    # 将日期列转换为 datetime 类型
    factor_df['dateTime'] = pd.to_datetime(factor_df['dateTime'])
    # 设置 MultiIndex，并提取因子值
    factor_series = factor_df.set_index(['dateTime', 'securityId']).sort_index()['min_return']

    # 重新构造 MultiIndex，确保第一层是 DatetimeIndex
    dates = pd.to_datetime(factor_series.index.get_level_values(0))
    security_ids = factor_series.index.get_level_values(1)
    new_index = pd.MultiIndex.from_arrays([dates, security_ids], names=factor_series.index.names)
    factor_series.index = new_index

    return factor_series


# ---------------------- 单日价格数据加载函数 ----------------------
def load_single_day_price(date, data_path):
    """
    读取某一天的价格数据 pickle 文件，并返回一个 Series。
    假设文件名为 "{date}.pkl"，数据中包含 'price' 列。
    如果数据为 MultiIndex，则尝试提取其中股票代码层（优先判断索引名中是否有 'stock_code'，
    否则默认取第二层）；如果为单索引，则依据 'securityId' 列构造索引。
    返回的 Series 以股票代码为索引，Series 的名称设为当前日期。
    """
    file_path = os.path.join(data_path, f"{date}.pkl")
    if not os.path.exists(file_path):
        print(f"文件 {file_path} 不存在，跳过该日数据")
        return None

    df = pd.read_pickle(file_path)

    if "close" not in df.columns:
        print(f"文件 {file_path} 缺少 'price' 列")
        return None

    # 判断是否为 MultiIndex
    if isinstance(df.index, pd.MultiIndex):
        if 'stock_code' in df.index.names:
            price_series = df["close"]
            price_series.index = price_series.index.get_level_values('stock_code')
        else:
            # 默认取第二层作为股票代码
            price_series = df["close"]
            price_series.index = price_series.index.get_level_values(1)
    else:
        # 如果是单索引，尝试用 'securityId' 列作为资产标识
        if 'securityId' in df.columns:
            price_series = df.set_index('securityId')["close"]
        elif 'stock_code' in df.columns:
            price_series = df.set_index('stock_code')["close"]
        else:
            print(f"文件 {file_path} 缺少资产标识列，跳过")
            return None

    return price_series.rename(date)


# ---------------------- 价格数据处理函数 ----------------------
def get_prices(date_list, data_path, max_workers=4):
    """
    使用多线程从按日存放的 pickle 文件中提取价格数据，
    将各日数据合并后返回一个 DataFrame和一个交易日历。
    返回的价格 DataFrame 格式要求：
      - 行索引为日期（datetime 类型，且为连续交易日）
      - 列为股票代码（securityId）
    同时返回一个交易日历（DatetimeIndex），直接由合成的价格数据索引得到。
    """
    price_list = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # 使用 lambda 传递 data_path 参数
        results = executor.map(lambda d: load_single_day_price(d, data_path), date_list)

    for p in results:
        if p is not None:
            price_list.append(p)

    if price_list:
        # 拼接后得到的 DataFrame 的列为日期，行索引为股票代码；需要转置
        price_df = pd.concat(price_list, axis=1).T
        price_df.index = pd.to_datetime(price_df.index)
        price_df = price_df.sort_index()
        return price_df
    else:
        print("未能获取任何价格数据")
        return pd.DataFrame(), pd.DatetimeIndex([])


def save_alphalens_plots(factor_data, save_dir="alphalens_plots"):
    """自动保存 Alphalens 生成的所有图表"""
    # 1. 清理内存并创建目录
    plt.close('all')
    gc.collect()
    os.makedirs(save_dir, exist_ok=True)

    # 2. 劫持 matplotlib 的显示函数
    original_show = plt.show
    plt.show = lambda: None  # 禁用交互式显示

    try:
        # 3. 生成分析报告（此时不会弹出窗口）
        al.tears.create_full_tear_sheet(factor_data)

        # 4. 遍历并保存所有图表
        for fig_num in plt.get_fignums():
            fig = plt.figure(fig_num)
            try:
                # 自动生成文件名（处理中文标题）
                title = fig._suptitle.get_text() if fig._suptitle else f"figure_{fig_num}"
                safe_title = "".join([c if c.isalnum() else "_" for c in title])
                file_path = os.path.join(save_dir, f"{safe_title}.png")

                # 保存并关闭图表
                fig.savefig(file_path, dpi=300, bbox_inches='tight')
                plt.close(fig)
                print(f"已保存：{file_path}")
            except Exception as e:
                print(f"图表 {fig_num} 保存失败：{str(e)}")
    finally:
        # 5. 恢复原始显示设置
        plt.show = original_show


# ---------------------- 主流程 ----------------------
if __name__ == '__main__':
    price_df = pd.read_pickle(
        'D:\\桌面\\pycharmprojects\\price_data_pivot.pkl')
    price_df = reshape_price_data(price_df.copy())
    print(price_df.head())

    df_factor = pd.read_pickle(
        "D:\\桌面\\pycharmprojects\\factor\\factor_52week_high2.pkl")
    df_factor = df_factor.copy()[['factor_52week_high']]

    # 没有设置成双索引的话先设置成双索引
    # df_factor = df_factor.set_index(['dateTime', 'securityId'])
    # 将索引的名字修改为 ['date', 'securityId']
    df_factor.index.set_names(['date', 'securityId', ], inplace=True)
    df_factor = df_factor.sort_index()
    print(df_factor.head())

    start_date = '2021-01-01'
    start_date = pd.to_datetime(start_date)
    idx = pd.IndexSlice
    df_factor_filtered = df_factor.loc[idx[start_date:, :], :]
    price_df_filtered = price_df.loc[start_date:]

    #    使用 alphalens 进行因子数据清洗和 forward returns 的计算
    #    注意：此处 prices 必须为行索引为日期、列为股票代码的 DataFrame，
    #    因子数据要求为 MultiIndex Series，索引为 (date, securityId)
    clean_factor_data = al.utils.get_clean_factor_and_forward_returns(
        factor=df_factor_filtered,  # MultiIndex Series，索引为 (date, securityId)
        prices=price_df_filtered,  # DataFrame，行索引为日期，列为股票代码
        periods=[1, 5, 10],  # 计算 5 日和 10 日 forward returns
        quantiles=5,  # 分组数目
    )

    print("清洗后的因子数据（用于 alphalens 分析）预览：")
    print(clean_factor_data.head())
    print(f"【结束】当前内存占用：{memory_usage():.2f} MB")

    # 5.1 进行分位数收益分析
    mean_returns, std_returns = mean_return_by_quantile(clean_factor_data)
    # 转换为DataFrame
    # 重置索引时单独处理分位数列
    quantile_mean_df = mean_returns.reset_index().rename(columns={"factor_quantile": "quantile"})
    quantile_std_df = std_returns.reset_index().rename(columns={"factor_quantile": "quantile"})

    # 仅对数值列添加前缀（排除分位数列）
    mean_cols = [col for col in quantile_mean_df.columns if col != 'quantile']
    std_cols = [col for col in quantile_std_df.columns if col != 'quantile']

    quantile_mean_df = quantile_mean_df[['quantile'] + mean_cols].add_prefix('mean_')
    quantile_std_df = quantile_std_df[['quantile'] + std_cols].add_prefix('std_')

    # 合并时保留分位数列
    quantile_df = pd.merge(
        quantile_mean_df.rename(columns={'mean_quantile': 'quantile'}),
        quantile_std_df.rename(columns={'std_quantile': 'quantile'}),
        on='quantile'
    )

    # 按照alphalens的标准换成bps
    quantile_df['mean_1D'] = (quantile_df.copy()['mean_1D'] * 10000).round(2)
    quantile_df['mean_5D'] = (quantile_df.copy()['mean_5D'] * 10000).round(2)
    quantile_df['mean_10D'] = (quantile_df.copy()['mean_10D'] * 10000).round(2)
    quantile_df['std_1D'] = (quantile_df.copy()['std_1D'] * 10000).round(2)
    quantile_df['std_5D'] = (quantile_df.copy()['std_5D'] * 10000).round(2)
    quantile_df['std_10D'] = (quantile_df.copy()['std_10D'] * 10000).round(2)

    quantile_df['quantile'] = quantile_df.copy()['quantile'].astype('str')

    # 5.2 获取信息系数序列（包含IC均值、IR比率等）
    # 生成IC数据（DataFrame格式，列名为5D/10D）
    ic_series = factor_information_coefficient(clean_factor_data)

    # 重构为规范的DataFrame结构
    ic_df = pd.DataFrame({
        'IC_mean': ic_series.mean(),  # 自动按列计算
        'IC_std': ic_series.std(),  # 注意原版Alphalens使用总体标准差
        'IR Ratio': ic_series.mean() / ic_series.std()
    }, index=ic_series.columns).T.rename_axis('Period', axis=1)

    # 修饰一下格式
    ic_df = ic_df.reset_index()
    ic_df['1D'] = ic_df.copy()['1D'].round(3)
    ic_df['5D'] = ic_df.copy()['5D'].round(3)
    ic_df['10D'] = ic_df.copy()['10D'].round(3)

    # 进行周转率手动计算
    turnover_df = calculate_turnover_metrics(clean_factor_data)

    # 预先在tear_sheet改变数据结构之前输出写入一次结果
    print('\n----------------------------')
    print('\n收益数据')
    print(quantile_df)
    print('\nic相关')
    print(ic_df)
    print('\因子换手率')
    print(turnover_df)
    print('\n----------------------------')

    output_path = 'D:\\桌面\\pycharmprojects\\factor\\factor_analysis_report.docx'

    dataframe_to_word(quantile_df,
                      output_path=output_path,
                      title="Return Analysis (bps)"
                      )
    dataframe_to_word(ic_df,
                      output_path=output_path,
                      title="IC Analysis"
                      )
    dataframe_to_word(turnover_df,
                      output_path=output_path,
                      title="Turnover Analysis (%)"
                      )

    # 4. 可选：生成完整分析报告（若希望直接生成 Tear Sheet）
    al.tears.create_full_tear_sheet(clean_factor_data)