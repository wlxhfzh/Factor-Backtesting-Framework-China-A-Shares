import os
import pandas as pd
from tqdm import tqdm

def load_and_merge_pkl_dirs(
    dir_list,
    start_date,
    end_date,
    prefix_cols=True
):
    """
    从多个目录中读取 .pkl 文件，按日期和证券ID做内连接合并，过滤零成交量证券，并统计丢弃的记录数。
    同时捕获并记录无法反序列化或索引构造失败的文件。

    参数:
        dir_list (list of str): 包含 .pkl 文件的目录路径列表。
        start_date (str or datetime-like): 起始日期，可与 pandas.to_datetime 兼容。
        end_date (str or datetime-like): 结束日期，可与 pandas.to_datetime 兼容。
        prefix_cols (bool): 是否根据源目录位置为列名添加前缀，默认 True。

    返回:
        merged_df (pd.DataFrame): 合并后的 DataFrame，索引为 MultiIndex(['dateTime', 'securityId'])。
        dropped_count (int): 与第一个目录生成的表相比，因取交集丢弃的行数。
        corrupted_files (list of str): 无法加载或处理的文件路径列表。
    """
    data_frames = []
    corrupted_files = []

    # 遍历每个数据源目录
    for idx, data_path in enumerate(dir_list):
        # 从路径获取目录标识，用于重命名 factorValue 列
        identifier = os.path.basename(os.path.normpath(data_path))
        dfs = []
        # 排除系统资源文件
        pkl_files = sorted(
            f for f in os.listdir(data_path)
            if f.endswith('.pkl') and not f.startswith('._')
        )
        for fn in tqdm(pkl_files, desc=f"读取 {data_path}"):
            file_path = os.path.join(data_path, fn)
            try:
                df = pd.read_pickle(file_path)
            except Exception as e:
                corrupted_files.append(file_path)
                print(f"跳过损坏或非 pickle 文件: {file_path}, 错误: {e}")
                continue

            # 如果存在 factorValue 列，则重命名为目录标识
            if 'factorValue' in df.columns:
                df = df.rename(columns={'factorValue': identifier})

            # 强制 MultiIndex(['dateTime','securityId'])
            if not isinstance(df.index, pd.MultiIndex):
                try:
                    if {'dateTime', 'securityId'}.issubset(df.columns):
                        df = df.set_index(['dateTime', 'securityId'])
                    else:
                        df.index = pd.MultiIndex.from_tuples(
                            df.index,
                            names=['dateTime', 'securityId']
                        )
                except Exception as e:
                    corrupted_files.append(file_path)
                    print(f"跳过索引构造失败文件: {file_path}, 错误: {e}")
                    continue

            # 转换第一级时间索引并排序
            df.index = df.index.set_levels(
                pd.to_datetime(df.index.levels[0]), level=0
            )
            df = df.sort_index()

            # 保留所有列
            dfs.append(df)

        if dfs:
            # 合并单源所有文件并按日期范围过滤
            full_df = pd.concat(dfs, axis=0).loc[start_date:end_date]
            if prefix_cols:
                full_df.columns = [f"src{idx}_{c}" for c in full_df.columns]
            data_frames.append(full_df)

    if not data_frames:
        return pd.DataFrame(), 0, corrupted_files

    # 第一个源为基准，统计初始行数
    base_df = data_frames[0]
    initial_count = len(base_df)
    merged_df = base_df.copy()

    # 依次与后续源做内连接
    for df in data_frames[1:]:
        merged_df = merged_df.join(df, how='inner')

    dropped_count = initial_count - len(merged_df)

    # 过滤零成交量证券（使用第一个源的 volume 列，如果存在）
    vol_col = 'src0_volume' if prefix_cols else 'volume'
    if vol_col in merged_df.columns:
        zero_secs = (
            merged_df.groupby(level='securityId')[vol_col].sum() == 0
        )
        zero_secs = zero_secs[zero_secs].index
        merged_df = merged_df[~merged_df.index.get_level_values('securityId').isin(zero_secs)]

    return merged_df, dropped_count, corrupted_files




if __name__ == "__main__":
    dirs = ['/Volumes/Elements/hb_data/daily_cbond_quota/',
            '/Volumes/Elements/hb_data/CBond_Option_Value/',
            '/Volumes/Elements/hb_data/cCBond_IV/',
            '/Volumes/Elements/hb_data/ConvertValue/',
            '/Volumes/Elements/hb_data/ConvPremiumRatio/',
            '/Volumes/Elements/hb_data/Ptm/',
            '/Volumes/Elements/hb_data/StrbValue/']
    merged_df, dropped, corrupted = load_and_merge_pkl_dirs(dirs, '2016-01-01', '2024-12-31', prefix_cols=False)
    print(f"丢弃了 {dropped} 条记录")
    print(corrupted)
    print(merged_df.head())

    merged_df.to_pickle('/Users/vincent/PycharmProjects/trading_strat/HWBS/GRU_model/dataset/whatabrandnewday.pkl')