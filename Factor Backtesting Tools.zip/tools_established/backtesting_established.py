import backtrader as bt
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.shared import Pt
from docx import Document
from docx.shared import Cm
import os


def mark_last_n_rows(df, group_col, time_col, n=60, new_col='is_last_n'):
    """
    对 DataFrame 按 group_col 分组后，按照 time_col 升序排序，
    并在每个组中将最后 n 行标记为1，不足 n 行则全部标记为1，
    其余行标记为0，新列名称默认为 new_col。

    参数:
      df: 待处理的 DataFrame
      group_col: 用于分组的列名称，例如 'securityId'
      time_col: 用于排序的时间戳列名称，例如 'dateTime'
      n: 每个组中需要标记为1的最后行数（默认为 60）
      new_col: 新增标记列的列名（默认为 'is_last_n'）

    返回:
      新的 DataFrame，其中新增一列 new_col，满足条件的行值为 1，其余为 0。
    """
    # 复制一份，避免修改原 DataFrame
    df = df.copy()

    # 确保 time_col 为 datetime 类型
    df[time_col] = pd.to_datetime(df[time_col])

    # 先按 group_col 和 time_col 升序排序
    df.sort_values([group_col, time_col], inplace=True)

    # 对每个分组计算行号（从 0 开始）
    df['_group_idx'] = df.groupby(group_col).cumcount()
    # 计算每个分组的总行数
    df['_group_size'] = df.groupby(group_col)[time_col].transform('count')

    # 如果所在组剩余行数 (group_size - group_idx) 小于等于 n，则标记为1，否则为0
    df[new_col] = ((df['_group_size'] - df['_group_idx']) <= n).astype(int)

    # 删除临时计算的列
    df.drop(columns=['_group_idx', '_group_size'], inplace=True)

    return df
class MyPandasData(bt.feeds.PandasData):
    # 定义自定义的 line
    lines = ('factor_tested', 'is_last60', 'vwap')
    # 默认参数，告诉 backtrader 从 DataFrame 中读取哪个列来填充该 line
    params = (
        ('factor_tested', 'daily_follow_coeff_ma10'),
        ('is_last60', -1),
        ('vwap', -1),
        ('printlog', True),
    )
def filtered_sec_dt(df, securityId):
    if df is None:
        raise ValueError("Missing DataFrame")
    if securityId is None:
        raise ValueError("Missing securityId")
    # 筛选指定标的数据，并以 dateTime 作为索引
    filtered_df = df[df['securityId'] == securityId].copy()
    filtered_df = filtered_df.set_index('dateTime')
    return filtered_df


def compute_excess_metrics_with_overall(merged_all):
    """
    计算每年的超额收益指标以及整个回测期间的总体指标，基于 merged_all 数据框。

    merged_all 需要包含以下列：
      - 'dateTime'：交易日期（或可转换为 datetime）
      - 'net_value'：策略净值
      - 'benchmark_net'：基准净值

    计算内容包括：
      - 年化超额收益率：基于当年（或整体）的累计超额收益曲线
      - 夏普比率：基于每日超额收益率的标准差年化（无风险率=0）
      - 最大回撤：基于累计超额收益曲线计算的最大回撤比例（相对回撤）
      - Calmar 比率：年化超额收益率 / 最大回撤（取正值）
      - 当年交易日数（仅作为参考）

    返回：
      一个 DataFrame，其中每行代表一个年份的指标，最后一行代表整体指标（year 列为 'Overall'）。
    """
    # 复制数据，确保不修改原始数据
    df = merged_all.copy()

    # 将 dateTime 转换为 datetime 类型并排序
    df['dateTime'] = pd.to_datetime(df['dateTime'])
    df.sort_values('dateTime', inplace=True)

    # 增加一个年份列，保留为普通列
    df['year'] = df['dateTime'].dt.year

    def calc_metrics(sub_df):
        # 按日期排序（sub_df已是单一年份或整体数据）
        sub_df = sub_df.sort_values('dateTime').copy()
        # 计算每日收益率
        sub_df['strategy_ret'] = sub_df['net_value'].pct_change()
        sub_df['benchmark_ret'] = sub_df['benchmark_net'].pct_change()
        # 超额收益率
        sub_df['excess_ret'] = sub_df['strategy_ret'] - sub_df['benchmark_ret']
        # 去除第一行可能的 NaN
        sub_df = sub_df.dropna(subset=['excess_ret'])
        if sub_df.empty:
            return None, None
        # 计算累计超额收益曲线，从1开始
        sub_df['cum_excess'] = (1 + sub_df['excess_ret']).cumprod()

        # 判断是否为单年数据
        start_date = sub_df['dateTime'].iloc[0]
        end_date = sub_df['dateTime'].iloc[-1]
        period_years = (end_date - start_date).days / 365.25

        # 如果 period_years 接近1，则直接用最后值减1，否则计算年化收益率
        if abs(period_years - 1) < 0.1:
            total_excess = sub_df['cum_excess'].iloc[-1] - 1
        else:
            total_excess = (sub_df['cum_excess'].iloc[-1]) ** (1 / period_years) - 1

        # 实际交易日数
        n_days = sub_df.shape[0]
        # 年化波动率：用每日超额收益率标准差乘以 sqrt(实际交易日数)
        annual_vol = sub_df['excess_ret'].std() * np.sqrt(n_days) if n_days > 0 else np.nan
        # 夏普比率（无风险率=0）
        sharpe = total_excess / annual_vol if annual_vol != 0 else np.nan
        # 最大回撤：以累计超额收益曲线为基础计算相对回撤
        cummax_excess = sub_df['cum_excess'].cummax()
        drawdown = (cummax_excess - sub_df['cum_excess']) / cummax_excess
        max_drawdown = drawdown.max()
        # Calmar Ratio：年化超额收益率 / 最大回撤
        calmar = total_excess / max_drawdown if max_drawdown != 0 else np.nan
        return {
            'annual_excess_return': total_excess,
            'sharpe': sharpe,
            'max_drawdown': max_drawdown,
            'calmar': calmar,
            'trading_days': n_days
        }, sub_df

    metrics_list = []
    # 按年份分组计算
    for year, group in df.groupby('year'):
        metrics, _ = calc_metrics(group)
        if metrics is not None:
            metrics['year'] = year
            metrics_list.append(metrics)

    # 计算整体指标（不分年份），整个数据集为一个整体
    overall_metrics, _ = calc_metrics(df)
    if overall_metrics is not None:
        overall_metrics['year'] = 'Overall'
        metrics_list.append(overall_metrics)

    return pd.DataFrame(metrics_list)


def dataframe_to_word(df, output_path="output.docx", title="数据报告"):
    """将DataFrame转换为Word表格"""
    # 创建文档对象
    # 加载或创建文档
    doc = Document(output_path) if os.path.exists(output_path) else Document()

    # 添加主标题（网页4方案）
    doc.add_heading(title, level=0)

    # 创建表格（网页1+网页3优化）
    table = doc.add_table(rows=df.shape[0] + 1, cols=df.shape[1])

    # 设置表头（网页4样式优化）
    header_cells = table.rows[0].cells
    for col_idx, col_name in enumerate(df.columns):
        header_cells[col_idx].text = str(col_name)
        header_cells[col_idx].paragraphs[0].runs[0].bold = True  # 加粗
        header_cells[col_idx].paragraphs[0].alignment = WD_PARAGRAPH_ALIGNMENT.CENTER  # 居中

    # 填充数据（网页1+网页5优化）
    for row_idx in range(df.shape[0]):
        row_data = df.iloc[row_idx]
        cells = table.rows[row_idx + 1].cells
        for col_idx, value in enumerate(row_data):
            cells[col_idx].text = str(value)
            cells[col_idx].paragraphs[0].alignment = WD_PARAGRAPH_ALIGNMENT.CENTER

    # 动态列宽调整
    for col_idx, column in enumerate(df.columns):
        max_length = max(df[column].astype(str).map(len).max(), len(column))
        table.columns[col_idx].width = Pt(max_length * 7)  # 按字符数动态计算

    # 设置表格边框和背景色
    table.style = 'Medium Shading 1 Accent 1'  # Word内置样式

    # 保存文档
    doc.save(output_path)


class CrossSectionalStrategy(bt.Strategy):
    params = (
        ('quantile', 5),
        ('target_group', 1),
        ('commission', 0.001),
        ('slippage', 0.0001),
    )

    def __init__(self):
        self.invalid_securities = set()  # 失效标的集合
        self.last_valid_price = dict()  # 最后有效价格记录
        self.data_dict = {data._name: data for data in self.datas}
        self.day_counter = 0
        self.last_turnover = 0.0
        # 用于记录每日数据的列表
        self.daily_records = []  # 每条记录为 dict: {'date': ..., 'value': ..., 'turnover': ...}
        # 为了记录成交额，初始化一个变量
        self._daily_trade_value = 0.0
        self.rebalance_history = []
        self.rebalance_history_daily = []
        self.order_book = []

    def notify_trade(self, trade):
        # trade 成交时累计成交金额（绝对值）
        if trade.isclosed:
            self._daily_trade_value += abs(trade.price * trade.size)

    def prenext(self):
        print("PRENEXT命令中时间戳为", self.datetime.date())
        print(f"当前净值为：{self.broker.getvalue()}")
        print(f"当前现金为：{self.broker.getcash()}")
        print(f"当前多头支数为 {self.get_held_securities()[0][0]} 支，金额为{self.get_held_securities()[0][1]}")
        print(f"当前空头支数为 {self.get_held_securities()[1][0]} 支，金额为{self.get_held_securities()[1][1]}")
        if [d._name for d, pos in self.getpositions().items() if pos.size < 0]:
            print([d._name for d, pos in self.getpositions().items() if pos.size < 0])
        # 每日记录一次净值和当日累计成交金额（换手率以成交额/组合市值计算）
        current_date = self.datetime.date(0)
        portfolio_value = self.broker.getvalue()
        # 当日换手率：成交额 / 当前组合市值（单位：百分比）
        turnover = self._daily_trade_value / portfolio_value if portfolio_value > 0 else 0.0
        self.daily_records.append({'date': current_date,
                                    'value': portfolio_value,
                                    'turnover': turnover})
        # 重置当日成交累计
        self._daily_trade_value = 0.0
        self.next()

        # 进行记录，绘制曲线用
        current_date = self.datetime.date(0)
        net_value = self.broker.getvalue()
        self.rebalance_history_daily.append((current_date, net_value))


    def next(self):
        """核心交易逻辑"""
        # 每个交易日计数加1

        # 当达到设定的调仓频率时，执行调仓逻辑
        if self.datetime.date(0) in trading_calendar['dateTime'].dt.date.values:

            # 第一步：检测并强平失效持仓
            self._check_and_force_close()

            # 第二步：执行正常调仓
            target_securities = self._select_valid_securities()
            self._safe_rebalance(target_securities)

            # 进行记录，绘制曲线用
            current_date = self.datetime.date(0)
            net_value = self.broker.getvalue()
            self.rebalance_history.append((current_date, net_value))

            # 进行记录，绘制统计tab用
            current_date = self.datetime.date(0)
            portfolio_value = self.broker.getvalue()
            turnover = self._daily_trade_value / portfolio_value if portfolio_value > 0 else 0.0
            self.daily_records.append({'date': current_date, 'value': portfolio_value, 'turnover': turnover})
            # 重置当日累计成交金额
            self._daily_trade_value = 0.0

    def _check_and_force_close(self):
        """强制平仓失效持仓（三重保障）"""
        for data, pos in self.getpositions().items():
            if pos.size == 0:
                continue

            if data.is_last60 == 1:
                print(f"强平触发: {data._name} ，系60日内到期或赎回")
                self.invalid_securities.add(data._name)

    def _select_valid_securities(self):
        """选股逻辑（严格过滤）"""
        valid = [
            data for data in self.datas
            if data.is_last60 == 0
               and data._name not in self.invalid_securities
        ]

        # 您的五分位逻辑
        if len(valid) < self.p.quantile:
            return []

        factors = [data.factor_tested[0] for data in valid]
        quantiles = pd.qcut(factors, self.p.quantile, labels=False)
        return [valid[i] for i in np.where(quantiles == (self.p.target_group - 1))[0]]

    def _safe_rebalance(self, targets):
        """安全调仓逻辑"""
        # 卖出非目标持仓
        current_holds = {d for d, pos in self.getpositions().items() if pos.size > 0}
        for data in current_holds - set(targets):
            self.close(data)

        # 买入目标持仓
        if targets:
            per_weight = 1.0 / len(targets)
            for data in targets:
                if data._name not in self.invalid_securities:
                    target_value = self.broker.getvalue() * per_weight
                    self.order_target_value(data, target_value)

    def notify_order(self, order):
        """订单状态处理"""
        if order.status == order.Completed:
            print(
                f"订单成交: {order.data._name} {order.executed.size} @ {order.executed.price:.2f}, {bt.num2date(order.executed.dt)}")
            self.order_book.append(
                [order.data._name, order.executed.size, order.executed.price, bt.num2date(order.executed.dt)])
            executed_value = abs(order.executed.price * order.executed.size)
            self._daily_trade_value += executed_value
        elif order.status != order.Completed:
            # 如果订单状态不是 Completed，则撤单
            self.cancel(order)

    def get_held_securities(self):
        """返回当前持有的证券数量"""
        long_securities = [d for d, pos in self.getpositions().items() if pos.size > 0]
        short_securities = [d for d, pos in self.getpositions().items() if pos.size < 0]
        long_positions = sum([pos.size * d.close for d, pos in self.getpositions().items() if pos.size > 0])
        short_positions = sum([pos.size * d.close for d, pos in self.getpositions().items() if pos.size < 0])
        num_held_list = [[len(long_securities), long_positions], [len(short_securities), short_positions]]
        return num_held_list

    def stop(self):
        # 将记录转换为 DataFrame，并存入策略变量，便于后续分析
        if not self.rebalance_history:
            print("没有调仓记录。")
            return

        viewing_start_date = pd.to_datetime('2021-01-01')
        viewing_end_date = pd.to_datetime('2024-12-31')

        # 处理净值序列
        df_history = pd.DataFrame(self.rebalance_history, columns=['date', 'net_value'])
        df_history['date'] = pd.to_datetime(df_history['date'])
        df_history = df_history.copy()[
            (df_history['date'] <= viewing_end_date) & (df_history['date'] >= viewing_start_date)]
        df_history.sort_values('date', inplace=True)
        df_history = df_history.copy().rename({'date': 'dateTime'}, axis=1)

        # 处理benchmark序列
        df_benchmark = pd.read_csv('/Users/vincent/PycharmProjects/trading_strat/HWBS/000832_benchmark.csv', usecols=['dateTime', 'close'])
        df_benchmark = df_benchmark.copy().rename(columns={'close': 'benchmark_net'})
        df_benchmark['dateTime'] = pd.to_datetime(df_benchmark['dateTime'])
        df_benchmark = df_benchmark.copy()[
            (df_benchmark['dateTime'] <= viewing_end_date) & (df_benchmark['dateTime'] >= viewing_start_date)]
        df_benchmark.sort_values('dateTime', inplace=True)

        # 形成merged_df, 对齐初始净值
        df_merged = pd.merge(df_history, df_benchmark, on='dateTime', how='inner')
        target_initial = 1000000
        scale_factor = target_initial / df_merged['benchmark_net'].iloc[0]
        df_merged['benchmark_net_adjusted'] = df_merged['benchmark_net'] * scale_factor

        # 先画一张全时段的
        df_allyear = df_merged.copy()[(df_merged['dateTime'] >= viewing_start_date) & (df_merged['dateTime'] <= viewing_end_date)]
        fig, ax1 = plt.subplots(figsize=(10, 6))

        # 计算累计收益率
        df_allyear['strategy_cum_return'] = df_allyear['net_value'].transform(
            lambda x: (x / x.iloc[0]) - 1)
        df_allyear['benchmark_cum_return'] = df_allyear['benchmark_net_adjusted'].transform(
            lambda x: (x / x.iloc[0]) - 1)

        # 计算超额累计收益率
        df_allyear['excess_cum_return'] = df_allyear['strategy_cum_return'] - df_allyear['benchmark_cum_return']

        df_timeseries = df_allyear.copy()

        # 准备回撤数据
        df_allyear['annual_cummax'] = df_allyear['net_value'].cummax()
        df_allyear['annual_drawdown'] = df_allyear['annual_cummax'] - df_allyear['net_value']
        df_allyear['drawdown_percentage'] = df_allyear['annual_drawdown'] / df_allyear['annual_cummax'] * 100

        # 绘制累计收益率曲线
        ax1.set_xlabel("Date")
        ax1.set_ylabel("Drawdown Percentage", color='red')
        ax1.tick_params(axis='y', labelcolor='red')
        ax1.set_ylim(0, 100)
        ax1.fill_between(df_allyear['dateTime'], df_allyear['drawdown_percentage'], color='red', alpha=0.3,
                         label='Drawdown Area')

        # 创建第二个 y 轴绘制收益率
        ax2 = ax1.twinx()
        ax2.plot(df_allyear['dateTime'], df_allyear['strategy_cum_return'], label='Strategy Cumulative Return',
                 color='blue')
        ax2.plot(df_allyear['dateTime'], df_allyear['benchmark_cum_return'], label='Benchmark Cumulative Return',
                 linestyle='--', color='green')
        ax2.plot(df_allyear['dateTime'], df_allyear['excess_cum_return'], label='Excess Cumulative Return',
                 linestyle='-.', color='orange')
        ax2.set_ylabel("Cumulative Return", color='black')
        ax2.tick_params(axis='y', labelcolor='black')
        ax2.legend(loc='upper left')

        # 设置标题
        plt.title(f"Cumulative Return and Drawdown from {viewing_start_date} to {viewing_end_date}")
        plt.grid(True)
        plt.tight_layout()

        # 显示图像
        plt.show()

        # 现在开始分年度绘制
        # 按年份分组
        df_merged['year'] = df_merged['dateTime'].dt.year

        # 计算累计收益率
        df_merged['strategy_cum_return'] = df_merged.groupby('year')['net_value'].transform(
            lambda x: (x / x.iloc[0]) - 1)
        df_merged['benchmark_cum_return'] = df_merged.groupby('year')['benchmark_net_adjusted'].transform(
            lambda x: (x / x.iloc[0]) - 1)

        # 计算超额累计收益率
        df_merged['excess_cum_return'] = df_merged['strategy_cum_return'] - df_merged['benchmark_cum_return']

        # 准备回撤数据
        df_merged['annual_cummax'] = df_merged.groupby('year')['net_value'].cummax()
        df_merged['annual_drawdown'] = df_merged['annual_cummax'] - df_merged['net_value']
        df_merged['drawdown_percentage'] = df_merged['annual_drawdown'] / df_merged['annual_cummax'] * 100

        years = sorted(df_merged['year'].unique())
        for yr in years:
            df_year = df_merged[df_merged['year'] == yr]
            fig, ax1 = plt.subplots(figsize=(10, 6))

            # 绘制累计收益率曲线
            ax1.set_xlabel("Date")
            ax1.set_ylabel("Drawdown Percentage", color='red')
            ax1.tick_params(axis='y', labelcolor='red')
            ax1.set_ylim(0, 100)
            ax1.fill_between(df_year['dateTime'], df_year['drawdown_percentage'], color='red', alpha=0.3,
                             label='Drawdown Area')

            # 创建第二个 y 轴绘制收益率
            ax2 = ax1.twinx()
            ax2.plot(df_year['dateTime'], df_year['strategy_cum_return'], label='Strategy Cumulative Return',
                     color='blue')
            ax2.plot(df_year['dateTime'], df_year['benchmark_cum_return'], label='Benchmark Cumulative Return',
                     linestyle='--', color='green')
            ax2.plot(df_year['dateTime'], df_year['excess_cum_return'], label='Excess Cumulative Return',
                     linestyle='-.', color='orange')
            ax2.set_ylabel("Cumulative Return", color='black')
            ax2.tick_params(axis='y', labelcolor='black')
            ax2.legend(loc='upper left')

            # 设置标题
            plt.title(f"Cumulative Return and Drawdown for {yr}")
            plt.grid(True)
            plt.tight_layout()

            # 显示图像
            plt.show()


        # 组合净值相关指标输出
        df_daily = pd.DataFrame(self.daily_records)
        df_daily['date'] = pd.to_datetime(df_daily['date'])
        df_daily = df_daily.copy()[(df_daily['date'] >= viewing_start_date) & (df_daily['date'] <= viewing_end_date)]
        df_daily.sort_values('date', inplace=True)
        df_daily.set_index('date', inplace=True)
        df_daily['year'] = df_daily.index.year

        # 年度净值：取每年首尾净值
        annual_net = df_daily.groupby('year')['value'].agg(first='first', last='last').reset_index()
        # 准备数据框素体
        df_netValue_output = annual_net.copy()
        # 年化收益率（简单计算）：(last/first - 1)*100%
        df_netValue_output['annual_return'] = annual_net.apply(lambda x: (x['last'] / x['first'] - 1) * 100, axis=1)
        # 年度最大回撤：计算当年每日净值最大回撤百分比（这里简单计算）
        annual_drawdown = df_daily.groupby('year')['value'].apply(
            lambda x: ((x.cummax() - x).max() / x.cummax().max()) * 100).reset_index().rename(columns={'value': 'annual_max_drawdown'})
        df_netValue_output = pd.merge(df_netValue_output, annual_drawdown, on='year', how='left')
        # 年度换手率：累加每日换手率
        annual_turnover = df_daily.groupby('year')['turnover'].sum().reset_index()
        df_netValue_output = pd.merge(df_netValue_output, annual_turnover, on='year', how='left')

        # 计算全时间值
        overall_first = df_daily['value'].iloc[0]
        overall_last = df_daily['value'].iloc[-1]
        # 全期累计收益率（简单计算），单位为百分比
        overall_return = (overall_last / overall_first - 1) * 100

        # 计算全期累计净值曲线的累计最高值
        overall_cummax = df_daily['value'].cummax()
        # 计算每日回撤百分比 = (累计最高 - 当日净值) / 累计最高 * 100
        overall_drawdown = (overall_cummax - df_daily['value']) / overall_cummax * 100
        overall_max_drawdown = overall_drawdown.max()

        # 累加全期换手率
        overall_turnover = df_daily['turnover'].sum()

        overall_metrics = {
            'year': 'Overall',
            'first': overall_first,
            'last': overall_last,
            'annual_return': overall_return,
            'annual_max_drawdown': overall_max_drawdown,
            'turnover': overall_turnover
        }

        overall_metrics_df = pd.DataFrame([overall_metrics])
        df_netValue_output = pd.concat([df_netValue_output.copy(), overall_metrics_df], axis=0, ignore_index=True)

        print("----------------- 组合净值统计指标 ------------------")
        print(df_netValue_output)


        # 处理净值序列
        df_history_daily = pd.DataFrame(self.rebalance_history_daily, columns=['date', 'net_value'])
        df_history_daily['date'] = pd.to_datetime(df_history_daily['date'])
        df_history_daily = df_history_daily.copy()[
            (df_history_daily['date'] >= viewing_start_date) & (df_history_daily['date'] <= viewing_end_date)]
        df_history_daily.sort_values('date', inplace=True)
        df_history_daily = df_history_daily.copy().rename({'date': 'dateTime'}, axis=1)

        # 处理benchmark序列
        df_benchmark_daily = pd.read_csv('/Users/vincent/PycharmProjects/trading_strat/HWBS/000832_benchmark.csv', usecols=['dateTime', 'close'])
        df_benchmark_daily = df_benchmark_daily.copy().rename(columns={'close': 'benchmark_net'})
        df_benchmark_daily['dateTime'] = pd.to_datetime(df_benchmark_daily['dateTime'])
        df_benchmark_daily = df_benchmark_daily.copy()[
            (df_benchmark_daily['dateTime'] >= viewing_start_date) & (df_benchmark_daily['dateTime'] <= viewing_end_date)]
        df_benchmark_daily.sort_values('dateTime', inplace=True)

        # 形成merged_df, 对齐初始净值
        merged_all = pd.merge(df_history_daily, df_benchmark_daily, on='dateTime', how='inner')
        target_initial = 1000000
        scale_factor = target_initial / merged_all['benchmark_net'].iloc[0]
        merged_all['benchmark_net_adjusted'] = merged_all['benchmark_net'] * scale_factor

        # 计算年度指标（基于超额收益）
        annual_metrics_df = compute_excess_metrics_with_overall(merged_all)
        turnover_df = df_netValue_output[['turnover', 'year']]
        annual_metrics_df = pd.merge(annual_metrics_df.copy(), turnover_df, on='year', how='left')

        print("-----------------超额收益统计指标-----------------：")
        print(annual_metrics_df)


        df_orderbook = pd.DataFrame(self.order_book, columns=["securityId", 'volume', "price", "timestamp"])

        # 进行输出内容的处理
        float_cols = annual_metrics_df.select_dtypes(include=['float64', 'int64']).columns.tolist()
        cols_to_round = [col for col in float_cols if col not in ['year', 'trading_days']]

        # 保留两位小数（仅针对数值列）
        annual_metrics_df[cols_to_round] = annual_metrics_df[cols_to_round].round(2)

        # 移动 year 列到首位（兼容列名动态变化）
        year_col = annual_metrics_df.pop('year')  # 提取列
        annual_metrics_df.insert(0, 'year', year_col)  # 插入到第一列

        # 输出到word
        dataframe_to_word(annual_metrics_df,
            output_path='/Users/vincent/PycharmProjects/trading_strat/HWBS/factor_cache/CorrPV/follow_coeff_ma/report_follow_coeff_ma.docx',
            title="Excess-return Performance"
        )

        """输出到excel(仅保留语句）"""
        # with pd.ExcelWriter("report_factor_000001.xlsx", engine="openpyxl") as writer:
            # df_netValue_output.to_excel(writer, sheet_name="portfolio_performance", index=False)
            # annual_metrics_df.to_excel(writer, sheet_name="excess_return_related", index=False)
            # df_timeseries.to_excel(writer, sheet_name="timeseries", index=False)
            # df_orderbook.to_excel(writer, sheet_name="order_book", index=False)


# ------------------- 主程序 -------------------
if __name__ == '__main__':
    # 初始化主脑
    cerebro = bt.Cerebro()


    trading_calendar = pd.read_pickle('/Users/vincent/PycharmProjects/trading_strat/HWBS/weekly_dates.pkl')
    # 读取 pkl 数据，进行筛选和指示变量添加
    df = pd.read_pickle("/Users/vincent/PycharmProjects/trading_strat/HWBS/factor_cache/CorrPV/follow_coeff_ma/enhanced_data.pkl")
    columns_to_keep = ['dateTime', 'securityId', 'open', 'high', 'low', 'close', 'volume', 'daily_follow_coeff_ma10', 'vwap']
    df = df[columns_to_keep]

    filtered_df = df[(df['dateTime'] >= '2021-01-01')]
    filtered_df = filtered_df.copy().dropna()
    df = filtered_df
    df = mark_last_n_rows(df, group_col='securityId', time_col='dateTime', n=45, new_col='is_last60')

    # 根据唯一的 securityId 动态添加数据流
    securities = df['securityId'].unique()
    for sec in securities:
        data_temp = filtered_sec_dt(df, sec)
        data = MyPandasData(dataname = data_temp)
        cerebro.adddata(data, name=sec)

    cerebro.addstrategy(CrossSectionalStrategy)
    cerebro.broker.setcash(1_000_000)
    cerebro.broker.setcommission(commission=0)
    cerebro.broker.set_slippage_perc(perc=0)

    # 添加内置分析器
    cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name='sharpe')
    cerebro.addanalyzer(bt.analyzers.DrawDown, _name='drawdown')
    cerebro.addanalyzer(bt.analyzers.AnnualReturn, _name='annualreturn')

    # 主脑，启动
    results = cerebro.run()
    strat = results[0]

    # 获取各个分析器的结果
    sharpe = strat.analyzers.sharpe.get_analysis()
    drawdown = strat.analyzers.drawdown.get_analysis()
    annual_return = strat.analyzers.annualreturn.get_analysis()

    # 输出结果
    print("Sharpe Ratio Analysis:")
    print(sharpe)
    print("\nDrawDown Analysis:")
    print(drawdown)
    print("\nAnnual Return Analysis:")
    print(annual_return)
