import os
import pandas as pd
import numpy as np
import alphalens as al
import matplotlib
matplotlib.rcParams['font.family'] = 'SimHei'
matplotlib.rcParams['axes.unicode_minus'] = False
import matplotlib.pyplot as plt
import seaborn as sns
from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from datetime import datetime
import io

def dataframe_to_word(df, doc, title="数据报告"):
    doc.add_heading(title, level=1)
    table = doc.add_table(rows=df.shape[0] + 1, cols=df.shape[1])
    table.style = 'Medium Shading 1 Accent 1'
    header_cells = table.rows[0].cells
    for col_idx, col_name in enumerate(df.columns):
        header_cells[col_idx].text = str(col_name)
        header_cells[col_idx].paragraphs[0].runs[0].bold = True
        header_cells[col_idx].paragraphs[0].alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    for row_idx in range(df.shape[0]):
        row_cells = table.rows[row_idx + 1].cells
        for col_idx, value in enumerate(df.iloc[row_idx]):
            row_cells[col_idx].text = str(value)
            row_cells[col_idx].paragraphs[0].alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    doc.add_paragraph('')

def reshape_price_data(df):
    df['dateTime'] = pd.to_datetime(df['dateTime'])
    df_sub = df[['dateTime', 'securityId', 'close']]
    price_df = df_sub.pivot(index='dateTime', columns='securityId', values='close')
    return price_df

def calculate_turnover_metrics(clean_factor_data):
    temp_data = pd.DataFrame({'factor_quantile': clean_factor_data['factor_quantile']})
    temp_data = temp_data.reset_index()
    temp_data['date'] = pd.to_datetime(temp_data['date'])
    temp_data.sort_values(['asset', 'date'], inplace=True)
    def calculate_turnover(data, window=1):
        data['changed'] = data.groupby('asset')['factor_quantile'].transform(
            lambda x: x.ne(x.shift(window)).astype(int)
        )
        q_turnover = data.groupby(['date', 'factor_quantile'])['changed'].mean().unstack()
        return q_turnover
    windows = {'1D': 1, '5D': 5, '10D': 10}
    turnover_dfs = {}
    for period, window in windows.items():
        turnover = calculate_turnover(temp_data, window)
        turnover_dfs[period] = pd.DataFrame({
            'quantile': turnover.columns.astype(str),
            f'turnover_mean_{period}': (turnover.mean() * 100).round(2),
            f'turnover_std_{period}': (turnover.std() * 100).round(2)
        }).reset_index(drop=True)
    result = turnover_dfs['1D']
    for period in ['5D', '10D']:
        result = pd.merge(result, turnover_dfs[period], on='quantile', how='outer')
    return result

def calculate_rank_autocorr(clean_factor_data, lag=1):
    df = clean_factor_data.reset_index()[['date', 'asset', 'factor']]
    df['asset'] = df['asset'].astype(str)
    dates = sorted(df['date'].unique())
    autocorrs = []
    result_dates = []
    for i in range(len(dates) - lag):
        date1 = dates[i]
        date2 = dates[i + lag]
        df1 = df[df['date'] == date1]
        df2 = df[df['date'] == date2]
        assets1 = set(df1['asset'].astype(str))
        assets2 = set(df2['asset'].astype(str))
        common_assets = assets1 & assets2
        if len(common_assets) < 2:
            autocorrs.append(np.nan)
            result_dates.append(date2)
            continue
        ranks1 = df1[df1['asset'].isin(common_assets)].set_index('asset')['factor'].rank()
        ranks2 = df2[df2['asset'].isin(common_assets)].set_index('asset')['factor'].rank()
        ranks1 = ranks1.loc[sorted(common_assets)]
        ranks2 = ranks2.loc[sorted(common_assets)]
        corr = ranks1.corr(ranks2)
        autocorrs.append(corr)
        result_dates.append(date2)
    return pd.Series(autocorrs, index=pd.to_datetime(result_dates))

def add_current_figure_to_word(doc, caption=None):
    img_stream = io.BytesIO()
    plt.savefig(img_stream, format='png', dpi=150, bbox_inches='tight')
    img_stream.seek(0)
    doc.add_picture(img_stream, width=Inches(6))
    if caption:
        doc.add_paragraph(caption)
    doc.add_paragraph('')
    plt.close()

def plot_turnover_and_rank_autocorr(clean_factor_data, doc):
    fig, axes = plt.subplots(4, 1, figsize=(10, 16))
    def calculate_turnover(data, quantile):
        quantile_data = data[data['factor_quantile'] == quantile]
        daily_holdings = quantile_data.groupby('date').apply(
            lambda x: set(x.index.get_level_values('asset').astype(str))
        )
        turnover = []
        dates = []
        prev_holdings = None
        for date, holdings in daily_holdings.items():
            if prev_holdings is not None:
                if len(holdings.union(prev_holdings)) > 0:
                    turnover_ratio = 1 - len(holdings.intersection(prev_holdings)) / len(
                        holdings.union(prev_holdings))
                else:
                    turnover_ratio = 0
                turnover.append(turnover_ratio)
                dates.append(date)
            prev_holdings = holdings
        return pd.Series(turnover, index=dates)
    turnover_5d_top = calculate_turnover(clean_factor_data, 5)
    turnover_5d_bottom = calculate_turnover(clean_factor_data, 1)
    axes[0].plot(turnover_5d_top.index, turnover_5d_top.values, color='deepskyblue', label='top quantile turnover')
    axes[0].plot(turnover_5d_bottom.index, turnover_5d_bottom.values, color='orange', label='bottom quantile turnover')
    axes[0].set_title('5D Period Top and Bottom Quantile Turnover')
    axes[0].set_ylabel('Proportion Of Names New To Quantile')
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)
    turnover_10d_top = calculate_turnover(clean_factor_data, 5)
    turnover_10d_bottom = calculate_turnover(clean_factor_data, 1)
    axes[1].plot(turnover_10d_top.index, turnover_10d_top.values, color='deepskyblue', label='top quantile turnover')
    axes[1].plot(turnover_10d_bottom.index, turnover_10d_bottom.values, color='orange', label='bottom quantile turnover')
    axes[1].set_title('10D Period Top and Bottom Quantile Turnover')
    axes[1].set_ylabel('Proportion Of Names New To Quantile')
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)
    autocorr_5d = calculate_rank_autocorr(clean_factor_data, lag=5)
    mean_autocorr_5d = autocorr_5d.mean()
    axes[2].plot(autocorr_5d.index, autocorr_5d.values, color='dodgerblue')
    axes[2].set_title('5D Period Factor Rank Autocorrelation')
    axes[2].set_ylabel('Autocorrelation Coefficient')
    axes[2].grid(True, alpha=0.3)
    axes[2].axhline(y=0, color='black', linestyle='-', alpha=0.3)
    axes[2].set_ylim(-1, 1)
    axes[2].text(0.01, 0.92, f"Mean {mean_autocorr_5d:.3f}", transform=axes[2].transAxes)
    autocorr_10d = calculate_rank_autocorr(clean_factor_data, lag=10)
    mean_autocorr_10d = autocorr_10d.mean()
    axes[3].plot(autocorr_10d.index, autocorr_10d.values, color='dodgerblue')
    axes[3].set_title('10D Period Factor Rank Autocorrelation')
    axes[3].set_ylabel('Autocorrelation Coefficient')
    axes[3].grid(True, alpha=0.3)
    axes[3].axhline(y=0, color='black', linestyle='-', alpha=0.3)
    axes[3].set_ylim(-1, 1)
    axes[3].text(0.01, 0.92, f"Mean {mean_autocorr_10d:.3f}", transform=axes[3].transAxes)
    plt.tight_layout()
    add_current_figure_to_word(doc, caption="Turnover and Rank Autocorrelation")

def plot_ic_and_distribution(clean_factor_data, doc):
    from scipy import stats
    ic = al.performance.factor_information_coefficient(clean_factor_data)
    periods = ['5D', '10D']
    fig = plt.figure(figsize=(10, 20))
    gs = fig.add_gridspec(5, 2, height_ratios=[1.1, 1.1, 1, 1, 1])
    ax1 = fig.add_subplot(gs[0, 0:2])
    ic_5d = ic['5D'].dropna()
    mean5d, std5d = ic_5d.mean(), ic_5d.std()
    ax1.plot(ic_5d.index, ic_5d.values, alpha=0.5, label='IC')
    ax1.plot(ic_5d.index, ic_5d.rolling(window=20, min_periods=1).mean(), color='green', label='1 month moving avg')
    ax1.set_title(f"5D Period Forward Return IC\nMean {mean5d:.3f}   Std. {std5d:.3f}")
    ax1.legend()
    ax1.grid(alpha=0.3)
    ax2 = fig.add_subplot(gs[1, 0:2])
    ic_10d = ic['10D'].dropna()
    mean10d, std10d = ic_10d.mean(), ic_10d.std()
    ax2.plot(ic_10d.index, ic_10d.values, alpha=0.5, label='IC')
    ax2.plot(ic_10d.index, ic_10d.rolling(window=20, min_periods=1).mean(), color='green', label='1 month moving avg')
    ax2.set_title(f"10D Period Forward Return IC\nMean {mean10d:.3f}   Std. {std10d:.3f}")
    ax2.legend()
    ax2.grid(alpha=0.3)
    ax3 = fig.add_subplot(gs[2, 0])
    ax3.hist(ic_5d, bins=40, alpha=0.7, density=True, color='skyblue', edgecolor='k')
    kde5d = stats.gaussian_kde(ic_5d)
    x5d = np.linspace(ic_5d.min(), ic_5d.max(), 200)
    ax3.plot(x5d, kde5d(x5d), color='blue')
    ax3.set_title(f"5D Period IC\nMean {mean5d:.3f}   Std. {std5d:.3f}")
    ax3.set_xlabel("IC")
    ax4 = fig.add_subplot(gs[2, 1])
    stats.probplot(ic_5d, dist="norm", plot=ax4)
    ax4.set_title("5D Period IC Normal Dist. Q-Q")
    ax5 = fig.add_subplot(gs[3, 0])
    ax5.hist(ic_10d, bins=40, alpha=0.7, density=True, color='skyblue', edgecolor='k')
    kde10d = stats.gaussian_kde(ic_10d)
    x10d = np.linspace(ic_10d.min(), ic_10d.max(), 200)
    ax5.plot(x10d, kde10d(x10d), color='blue')
    ax5.set_title(f"10D Period IC\nMean {mean10d:.3f}   Std. {std10d:.3f}")
    ax5.set_xlabel("IC")
    ax6 = fig.add_subplot(gs[3, 1])
    stats.probplot(ic_10d, dist="norm", plot=ax6)
    ax6.set_title("10D Period IC Normal Dist. Q-Q")
    ax7 = fig.add_subplot(gs[4, 0])
    ic_5d_month = ic_5d.groupby([ic_5d.index.year, ic_5d.index.month]).mean().unstack()
    im7 = ax7.imshow(ic_5d_month, aspect='auto', cmap='coolwarm', vmin=-0.2, vmax=0.2)
    for (i, j), val in np.ndenumerate(ic_5d_month):
        ax7.text(j, i, f"{val:.2f}" if not np.isnan(val) else '', ha='center', va='center', fontsize=8)
    ax7.set_title("Monthly Mean 5D Period IC")
    ax7.set_xlabel("Month")
    ax7.set_ylabel("Year")
    ax7.set_xticks(np.arange(12))
    ax7.set_xticklabels(range(1, 13))
    ax7.set_yticks(np.arange(ic_5d_month.shape[0]))
    ax7.set_yticklabels(ic_5d_month.index)
    ax8 = fig.add_subplot(gs[4, 1])
    ic_10d_month = ic_10d.groupby([ic_10d.index.year, ic_10d.index.month]).mean().unstack()
    im8 = ax8.imshow(ic_10d_month, aspect='auto', cmap='coolwarm', vmin=-0.2, vmax=0.2)
    for (i, j), val in np.ndenumerate(ic_10d_month):
        ax8.text(j, i, f"{val:.2f}" if not np.isnan(val) else '', ha='center', va='center', fontsize=8)
    ax8.set_title("Monthly Mean 10D Period IC")
    ax8.set_xlabel("Month")
    ax8.set_ylabel("Year")
    ax8.set_xticks(np.arange(12))
    ax8.set_xticklabels(range(1, 13))
    ax8.set_yticks(np.arange(ic_10d_month.shape[0]))
    ax8.set_yticklabels(ic_10d_month.index)
    fig.tight_layout()
    add_current_figure_to_word(doc, caption="IC分析六联图")

def plot_quantile_return_4in1(clean_factor_data, doc):
    import matplotlib.dates as mdates
    mean_returns, std_returns = al.performance.mean_return_by_quantile(clean_factor_data)
    quantiles = mean_returns.index
    periods = ['5D', '10D']
    fig, axes = plt.subplots(4, 1, figsize=(10, 18), gridspec_kw={'height_ratios': [1, 1.2, 1.5, 1.5]})
    bar_width = 0.35
    x = np.arange(len(quantiles))
    for idx, period in enumerate(periods):
        offset = (idx - 0.5) * bar_width
        axes[0].bar(x + offset, mean_returns[period]*10000, width=bar_width, label=period)
    axes[0].set_xticks(x)
    axes[0].set_xticklabels([str(q) for q in quantiles])
    axes[0].set_ylabel('Mean Return (bps)')
    axes[0].set_title("Mean Period Wise Return By Factor Quantile")
    axes[0].legend()
    axes[0].grid(alpha=0.3)
    quantile_returns = []
    for period in periods:
        for q in quantiles:
            data = clean_factor_data[clean_factor_data['factor_quantile'] == q][period].dropna() * 10000
            quantile_returns.append(pd.DataFrame({
                'quantile': str(q),
                'period': period,
                'return': data
            }))
    quantile_returns = pd.concat(quantile_returns, ignore_index=True)
    if quantile_returns['period'].nunique() == 2:
        sns.violinplot(data=quantile_returns, x='quantile', y='return', hue='period', split=True, ax=axes[1])
    else:
        sns.violinplot(data=quantile_returns, x='quantile', y='return', hue='period', split=False, ax=axes[1])
    axes[1].set_title('Period Wise Return By Factor Quantile')
    axes[1].set_ylabel('Return (bps)')
    axes[1].legend(title='forward_periods')
    axes[1].grid(alpha=0.3)
    for i, period in enumerate(periods):
        top = clean_factor_data[clean_factor_data['factor_quantile'] == quantiles.max()].groupby('date')[period].mean() * 10000
        bottom = clean_factor_data[clean_factor_data['factor_quantile'] == quantiles.min()].groupby('date')[period].mean() * 10000
        spread = top - bottom
        axes[2+i].plot(spread.index, spread.values, alpha=0.5, label='mean returns spread')
        if len(spread) > 20:
            rolling = spread.rolling(window=20, min_periods=1).mean()
            axes[2+i].plot(rolling.index, rolling.values, color='orangered', label='1 month moving avg')
        axes[2+i].set_ylabel('Difference in Quantile Mean Return (bps)')
        axes[2+i].set_title(f"Top Minus Bottom Quantile Mean Return ({period} Period Forward Return)")
        axes[2+i].legend()
        axes[2+i].grid(alpha=0.3)
    plt.tight_layout()
    add_current_figure_to_word(doc, caption='分位收益分析四联图')

def calc_and_plot_yearly_cum_return_drawdown(clean_factor_data, year, doc, period='1D'):
    """
    输出：年度或整体净值/回撤图，并返回业绩指标dict。
    year可以为具体年份，也可以为'Overall'。
    """
    import matplotlib.dates as mdates
    import matplotlib.pyplot as plt
    import io
    from docx.shared import Inches

    df = clean_factor_data.reset_index()
    if year != 'Overall':
        df['year'] = df['date'].dt.year
        dfy = df[df['year'] == year]
    else:
        dfy = df
    if dfy.empty:
        print(f"{year}年无数据，跳过。")
        return None

    grouped = dfy.groupby('date')
    daily_strategy = grouped.apply(lambda x: x[x['factor_quantile'] == 5][period].mean())
    daily_benchmark = grouped.apply(lambda x: x[x['factor_quantile'] == 1][period].mean())
    daily = pd.DataFrame({'strategy': daily_strategy, 'benchmark': daily_benchmark})
    daily['excess'] = daily['strategy'] - daily['benchmark']
    daily = daily.fillna(0)

    cum_strategy = (1 + daily['strategy']).cumprod()
    cum_benchmark = (1 + daily['benchmark']).cumprod()
    cum_excess = (1 + daily['excess']).cumprod()

    rollmax = cum_strategy.cummax()
    drawdown = (cum_strategy / rollmax) - 1
    abs_drawdown = -drawdown * 100

    cum_return = cum_excess.iloc[-1] - 1
    max_drawdown = drawdown.min()
    calmar = cum_return / abs(max_drawdown) if max_drawdown != 0 else np.nan
    ann_vol = daily['excess'].std() * (252 ** 0.5)
    sharpe = cum_return / ann_vol if ann_vol > 0 else np.nan
    trading_days = len(daily)
    turnover = dfy[dfy['factor_quantile'].isin([1,5])].shape[0] / trading_days

    strategy_pct = (cum_strategy - 1) * 100
    benchmark_pct = (cum_benchmark - 1) * 100
    excess_pct = (cum_excess - 1) * 100

    if year != 'Overall':
        fig, ax1 = plt.subplots(figsize=(8, 4.5))
        ax2 = ax1.twinx()
        ax1.fill_between(abs_drawdown.index, 0, abs_drawdown.values, color='lightcoral', alpha=0.5, step='mid')
        ax1.set_ylabel('Drawdown (%)', color='red')
        ax1.set_ylim(0, abs_drawdown.max() * 1.2 if abs_drawdown.max() > 10 else 10)
        ax1.tick_params(axis='y', labelcolor='red')
        ax2.plot(strategy_pct.index, strategy_pct.values, 'b-', label='Strategy Cumulative Return (%)', linewidth=1.5)
        ax2.plot(benchmark_pct.index, benchmark_pct.values, 'g--', label='Benchmark Cumulative Return (%)', linewidth=1.2)
        ax2.plot(excess_pct.index, excess_pct.values, 'orange', linestyle='-.', label='Excess Cumulative Return (%)', linewidth=1.2)
        ax2.set_ylabel('Cumulative Return (%)')
        ax2.tick_params(axis='y')
        ax2.legend(loc='upper left', fontsize=8)
        plt.title(f"Cumulative Return and Drawdown for {year}")
        ax1.xaxis.set_major_locator(mdates.MonthLocator())
        ax1.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
        plt.setp(ax1.xaxis.get_majorticklabels(), rotation=25)
        plt.tight_layout()
        img_stream = io.BytesIO()
        plt.savefig(img_stream, format='png', dpi=150, bbox_inches='tight')
        img_stream.seek(0)
        doc.add_picture(img_stream, width=Inches(5))
        doc.add_paragraph(f'Cumulative Return and Drawdown for {year}')
        plt.close()

    return {
        'year': year,
        'cumulative_excess_return': cum_return,
        'sharpe': sharpe,
        'max_drawdown': max_drawdown,
        'calmar': calmar,
        'trading_days': trading_days,
        'turnover': turnover,
    }

def calc_excess_return_performance_table_and_plot(clean_factor_data, doc, period='1D'):
    """
    汇总年度和overall业绩表，年度画图，overall不画图，写入word。
    """
    all_stats = []
    years = sorted(clean_factor_data.reset_index()['date'].dt.year.unique())
    for year in years:
        stats = calc_and_plot_yearly_cum_return_drawdown(clean_factor_data, year, doc, period=period)
        if stats:
            all_stats.append(stats)
    # Overall
    stats = calc_and_plot_yearly_cum_return_drawdown(clean_factor_data, 'Overall', doc, period=period)
    if stats:
        all_stats.append(stats)
    perf_df = pd.DataFrame(all_stats)
    perf_df['cumulative_excess_return'] = perf_df['cumulative_excess_return'].apply(lambda x: f"{x:.2%}")
    perf_df['sharpe'] = perf_df['sharpe'].apply(lambda x: f"{x:.2f}")
    perf_df['max_drawdown'] = perf_df['max_drawdown'].apply(lambda x: f"{x:.2%}")
    perf_df['calmar'] = perf_df['calmar'].apply(lambda x: f"{x:.2f}")
    perf_df['turnover'] = perf_df['turnover'].apply(lambda x: f"{x:.2f}")
    dataframe_to_word(perf_df, doc, title="Excess-return Performance (Cumulative, matches chart)")
    return perf_df

def backtest_and_report(input_csv_path, factor_name, output_report_dir, start_date='2021-01-01', max_loss=0.85):
    print(f"【进度】读取含因子的csv: {input_csv_path}")
    df_raw = pd.read_csv(input_csv_path)
    print(f"【DEBUG】{factor_name} 非空比例：", df_raw[factor_name].notnull().mean())
    print(f"【DEBUG】{factor_name} 唯一值数量：", df_raw[factor_name].nunique())
    print(f"【DEBUG】{factor_name} 前10个：", df_raw[factor_name].dropna().head(10).tolist())
    df_raw['dateTime'] = pd.to_datetime(df_raw['dateTime'])
    df_raw = df_raw.sort_values(['securityId', 'dateTime'])
    price_df = reshape_price_data(df_raw)
    price_df = price_df.loc[pd.to_datetime(start_date):]
    os.makedirs(output_report_dir, exist_ok=True)
    if factor_name not in df_raw.columns:
        print(f"【跳过】{factor_name} 未在数据表中")
        return
    df_fac = df_raw[['dateTime', 'securityId', factor_name]].rename(columns={factor_name: 'factor'}).dropna()
    if df_fac.empty:
        print(f"【跳过】{factor_name}数据为空")
        return
    print(f"  [Alphalens清洗] {factor_name} ...")
    df_fac = df_fac.set_index(['dateTime', 'securityId']).sort_index()
    try:
        clean_factor_data = al.utils.get_clean_factor_and_forward_returns(
            factor=df_fac,
            prices=price_df,
            periods=[1, 5, 10],
            quantiles=5,
            max_loss=max_loss,
        )
    except Exception as e:
        print(f"  [跳过] {factor_name} 报错: {e}")
        return
    print(f"[{factor_name}] clean_factor_data.head():")
    print(clean_factor_data.head())
    output_path = os.path.join(output_report_dir, f"factor_analysis_report_{factor_name}.docx")
    if os.path.exists(output_path):
        os.remove(output_path)
    doc = Document()
    doc.add_heading(f'因子分析报告：{factor_name}', level=0)
    current_time = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
    doc.add_paragraph(f'生成时间: {current_time}\n')
    mean_returns, std_returns = al.performance.mean_return_by_quantile(clean_factor_data)
    quantile_mean_df = mean_returns.reset_index().rename(columns={"factor_quantile": "quantile"})
    quantile_std_df = std_returns.reset_index().rename(columns={"factor_quantile": "quantile"})
    mean_cols = [col for col in quantile_mean_df.columns if col != 'quantile']
    std_cols = [col for col in quantile_std_df.columns if col != 'quantile']
    quantile_mean_df = quantile_mean_df[['quantile'] + mean_cols].add_prefix('mean_')
    quantile_std_df = quantile_std_df[['quantile'] + std_cols].add_prefix('std_')
    quantile_df = pd.merge(
        quantile_mean_df.rename(columns={'mean_quantile': 'quantile'}),
        quantile_std_df.rename(columns={'std_quantile': 'quantile'}),
        on='quantile'
    )
    for period in ['1D', '5D', '10D']:
        quantile_df[f'mean_{period}'] = (quantile_df[f'mean_{period}'] * 10000).round(2)
        quantile_df[f'std_{period}'] = (quantile_df[f'std_{period}'] * 10000).round(2)
    quantile_df['quantile'] = quantile_df['quantile'].astype('str')
    ic_series = al.performance.factor_information_coefficient(clean_factor_data)
    ic_df = pd.DataFrame({
        'IC_mean': ic_series.mean(),
        'IC_std': ic_series.std(),
        'IR Ratio': ic_series.mean() / ic_series.std()
    }, index=ic_series.columns).T.rename_axis('Period', axis=1)
    ic_df = ic_df.reset_index()
    for period in ['1D', '5D', '10D']:
        ic_df[period] = ic_df[period].round(3)
    turnover_df = calculate_turnover_metrics(clean_factor_data)
    dataframe_to_word(quantile_df, doc, title="Return Analysis (bps)")
    dataframe_to_word(ic_df, doc, title="IC Analysis")
    dataframe_to_word(turnover_df, doc, title="Turnover Analysis (%)")
    plot_quantile_return_4in1(clean_factor_data, doc)
    plot_ic_and_distribution(clean_factor_data, doc)
    plot_turnover_and_rank_autocorr(clean_factor_data, doc)
    # 年度和overall业绩表、年度净值回撤图
    calc_excess_return_performance_table_and_plot(clean_factor_data, doc, period='1D')
    doc.save(output_path)
    print(f"  [完成] {factor_name} 分析报告已保存: {output_path}")

if __name__ == '__main__':
    factor_csv_dir = 'D:\\桌面\\pycharmprojects\\factor\\csvs\\'
    output_report_dir = 'D:\\桌面\\pycharmprojects\\factor\\reports\\'
    factor_names = [
         '负偏度系数' ]
    for factor_name in factor_names:
        input_csv_path = os.path.join(factor_csv_dir, f'量价_{factor_name}.csv')
        backtest_and_report(
            input_csv_path=input_csv_path,
            factor_name=factor_name,
            output_report_dir=output_report_dir,
            start_date='2021-01-01',
            max_loss=0.99
        )