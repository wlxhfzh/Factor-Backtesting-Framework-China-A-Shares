import os
import pandas as pd
import numpy as np
import alphalens as al
import matplotlib

matplotlib.rcParams['font.family'] = 'SimHei'
matplotlib.rcParams['axes.unicode_minus'] = False
import matplotlib.pyplot as plt
import seaborn as sns
from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from datetime import datetime
import io
from scipy import stats  # Added for plot_ic_and_distribution


# ========== 辅助函数 ==========
def dataframe_to_word(df, doc, title="数据报告"):
    doc.add_heading(title, level=1)
    table = doc.add_table(rows=df.shape[0] + 1, cols=df.shape[1])
    table.style = 'Medium Shading 1 Accent 1'
    header_cells = table.rows[0].cells
    for col_idx, col_name in enumerate(df.columns):
        header_cells[col_idx].text = str(col_name)
        header_cells[col_idx].paragraphs[0].runs[0].bold = True
        header_cells[col_idx].paragraphs[0].alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    for row_idx in range(df.shape[0]):
        row_cells = table.rows[row_idx + 1].cells
        for col_idx, value in enumerate(df.iloc[row_idx]):
            row_cells[col_idx].text = str(value)
            row_cells[col_idx].paragraphs[0].alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    doc.add_paragraph('')


def reshape_price_data(df):
    df['dateTime'] = pd.to_datetime(df['dateTime'])
    df_sub = df[['dateTime', 'securityId', 'close']]
    price_df = df_sub.pivot(index='dateTime', columns='securityId', values='close')
    return price_df


def calculate_turnover_metrics(clean_factor_data):
    temp_data = pd.DataFrame({'factor_quantile': clean_factor_data['factor_quantile']})
    temp_data = temp_data.reset_index()
    temp_data['date'] = pd.to_datetime(temp_data['date'])
    temp_data.sort_values(['asset', 'date'], inplace=True)

    def calculate_turnover_series(data, window=1):  # Renamed inner function
        data['changed'] = data.groupby('asset')['factor_quantile'].transform(
            lambda x: x.ne(x.shift(window)).astype(int)
        )
        q_turnover = data.groupby(['date', 'factor_quantile'])['changed'].mean().unstack()
        return q_turnover

    windows = {'1D': 1, '5D': 5, '10D': 10}
    turnover_dfs = {}
    for period_key, window in windows.items():  # Changed period to period_key to avoid conflict
        turnover = calculate_turnover_series(temp_data.copy(), window)  # Pass a copy
        turnover_dfs[period_key] = pd.DataFrame({
            'quantile': turnover.columns.astype(str),
            f'turnover_mean_{period_key}': (turnover.mean() * 100).round(2),
            f'turnover_std_{period_key}': (turnover.std() * 100).round(2)
        }).reset_index(drop=True)
    result = turnover_dfs['1D']
    for period_key in ['5D', '10D']:
        result = pd.merge(result, turnover_dfs[period_key], on='quantile', how='outer')
    return result


def calculate_rank_autocorr(clean_factor_data, lag=1):
    df = clean_factor_data.reset_index()[['date', 'asset', 'factor']]
    df['asset'] = df['asset'].astype(str)
    df['date'] = pd.to_datetime(df['date'])  # Ensure date is datetime
    dates = sorted(df['date'].unique())
    autocorrs = []
    result_dates = []
    for i in range(len(dates) - lag):
        date1 = dates[i]
        date2 = dates[i + lag]
        df1 = df[df['date'] == date1]
        df2 = df[df['date'] == date2]
        assets1 = set(df1['asset'].astype(str))
        assets2 = set(df2['asset'].astype(str))
        common_assets = assets1 & assets2
        if len(common_assets) < 2:
            autocorrs.append(np.nan)
            result_dates.append(date2)
            continue
        ranks1 = df1[df1['asset'].isin(common_assets)].set_index('asset')['factor'].rank()
        ranks2 = df2[df2['asset'].isin(common_assets)].set_index('asset')['factor'].rank()
        ranks1 = ranks1.loc[sorted(list(common_assets))]  # Ensure order
        ranks2 = ranks2.loc[sorted(list(common_assets))]  # Ensure order
        corr = ranks1.corr(ranks2)
        autocorrs.append(corr)
        result_dates.append(date2)
    return pd.Series(autocorrs, index=pd.to_datetime(result_dates))


def add_current_figure_to_word(doc, caption=None):
    img_stream = io.BytesIO()
    plt.savefig(img_stream, format='png', dpi=150, bbox_inches='tight')
    img_stream.seek(0)
    doc.add_picture(img_stream, width=Inches(6))
    if caption:
        doc.add_paragraph(caption)
    doc.add_paragraph('')
    plt.close()


# ========== 主要图表绘制函数 ==========
def plot_turnover_and_rank_autocorr(clean_factor_data, doc):
    fig, axes = plt.subplots(4, 1, figsize=(10, 16))

    # Inner calculate_turnover for this specific plot (different from calculate_turnover_metrics)
    def calculate_plot_turnover(data, quantile_val):  # Renamed quantile to quantile_val
        quantile_data = data[data['factor_quantile'] == quantile_val]
        daily_holdings = quantile_data.groupby(level='date').apply(  # group by date level of index
            lambda x: set(x.index.get_level_values('asset').astype(str))
        )
        turnover_list = []  # Renamed turnover to turnover_list
        dates_list = []  # Renamed dates to dates_list
        prev_holdings = None
        # Ensure daily_holdings is sorted by date if not already
        sorted_daily_holdings = daily_holdings.sort_index()

        for date_val, holdings in sorted_daily_holdings.items():  # Renamed date to date_val
            if prev_holdings is not None:
                if len(holdings.union(prev_holdings)) > 0:
                    turnover_ratio = 1 - len(holdings.intersection(prev_holdings)) / len(
                        holdings.union(prev_holdings))
                else:
                    turnover_ratio = 0  # Or np.nan if preferred for no commonality
                turnover_list.append(turnover_ratio)
                dates_list.append(date_val)
            prev_holdings = holdings
        return pd.Series(turnover_list, index=pd.to_datetime(dates_list))

    turnover_5d_top = calculate_plot_turnover(clean_factor_data.copy(), 5)  # Use .copy()
    turnover_5d_bottom = calculate_plot_turnover(clean_factor_data.copy(), 1)
    axes[0].plot(turnover_5d_top.index, turnover_5d_top.values, color='deepskyblue', label='top quantile turnover')
    axes[0].plot(turnover_5d_bottom.index, turnover_5d_bottom.values, color='orange', label='bottom quantile turnover')
    axes[0].set_title('Top and Bottom Quantile Turnover (Based on 1D change in constituents)')  # Clarified title
    axes[0].set_ylabel('Proportion Of Names New To Quantile')
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)

    # The original code for 10D plot used the same 1D change logic.
    # If you need turnover based on 5D or 10D holding periods, the calculate_plot_turnover logic needs adjustment.
    # For now, assuming the plots are for 1-day change in constituents for top/bottom quantiles.
    axes[1].plot(turnover_5d_top.index, turnover_5d_top.values, color='deepskyblue',
                 label='top quantile turnover')  # Re-using 1D change for plot
    axes[1].plot(turnover_5d_bottom.index, turnover_5d_bottom.values, color='orange', label='bottom quantile turnover')
    axes[1].set_title('Top and Bottom Quantile Turnover (Based on 1D change in constituents)')  # Clarified title
    axes[1].set_ylabel('Proportion Of Names New To Quantile')
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)

    autocorr_5d = calculate_rank_autocorr(clean_factor_data, lag=5)
    mean_autocorr_5d = autocorr_5d.mean()
    axes[2].plot(autocorr_5d.index, autocorr_5d.values, color='dodgerblue')
    axes[2].set_title('5D Period Factor Rank Autocorrelation')
    axes[2].set_ylabel('Autocorrelation Coefficient')
    axes[2].grid(True, alpha=0.3)
    axes[2].axhline(y=0, color='black', linestyle='-', alpha=0.3)
    axes[2].set_ylim(-1, 1)
    if pd.notnull(mean_autocorr_5d):
        axes[2].text(0.01, 0.92, f"Mean {mean_autocorr_5d:.3f}", transform=axes[2].transAxes)

    autocorr_10d = calculate_rank_autocorr(clean_factor_data, lag=10)
    mean_autocorr_10d = autocorr_10d.mean()
    axes[3].plot(autocorr_10d.index, autocorr_10d.values, color='dodgerblue')
    axes[3].set_title('10D Period Factor Rank Autocorrelation')
    axes[3].set_ylabel('Autocorrelation Coefficient')
    axes[3].grid(True, alpha=0.3)
    axes[3].axhline(y=0, color='black', linestyle='-', alpha=0.3)
    axes[3].set_ylim(-1, 1)
    if pd.notnull(mean_autocorr_10d):
        axes[3].text(0.01, 0.92, f"Mean {mean_autocorr_10d:.3f}", transform=axes[3].transAxes)

    plt.tight_layout()
    add_current_figure_to_word(doc, caption="Turnover and Rank Autocorrelation")


def plot_ic_and_distribution(clean_factor_data, doc):
    ic = al.performance.factor_information_coefficient(clean_factor_data)
    periods_list = ['5D', '10D']  # Renamed periods to periods_list
    fig = plt.figure(figsize=(10, 20))
    gs = fig.add_gridspec(5, 2, height_ratios=[1.1, 1.1, 1, 1, 1])

    ax1 = fig.add_subplot(gs[0, 0:2])
    ic_5d = ic['5D'].dropna()
    mean5d, std5d = ic_5d.mean(), ic_5d.std()
    ax1.plot(ic_5d.index, ic_5d.values, alpha=0.5, label='IC')
    if len(ic_5d) > 0: ax1.plot(ic_5d.index, ic_5d.rolling(window=20, min_periods=1).mean(), color='green',
                                label='1 month moving avg')
    ax1.set_title(f"5D Period Forward Return IC\nMean {mean5d:.3f}   Std. {std5d:.3f}")
    ax1.legend()
    ax1.grid(alpha=0.3)

    ax2 = fig.add_subplot(gs[1, 0:2])
    ic_10d = ic['10D'].dropna()
    mean10d, std10d = ic_10d.mean(), ic_10d.std()
    ax2.plot(ic_10d.index, ic_10d.values, alpha=0.5, label='IC')
    if len(ic_10d) > 0: ax2.plot(ic_10d.index, ic_10d.rolling(window=20, min_periods=1).mean(), color='green',
                                 label='1 month moving avg')
    ax2.set_title(f"10D Period Forward Return IC\nMean {mean10d:.3f}   Std. {std10d:.3f}")
    ax2.legend()
    ax2.grid(alpha=0.3)

    if len(ic_5d) > 1:  # KDE and probplot need more than 1 point
        ax3 = fig.add_subplot(gs[2, 0])
        ax3.hist(ic_5d, bins=40, alpha=0.7, density=True, color='skyblue', edgecolor='k')
        kde5d = stats.gaussian_kde(ic_5d)
        x5d = np.linspace(ic_5d.min(), ic_5d.max(), 200)
        ax3.plot(x5d, kde5d(x5d), color='blue')
        ax3.set_title(f"5D Period IC\nMean {mean5d:.3f}   Std. {std5d:.3f}")
        ax3.set_xlabel("IC")

        ax4 = fig.add_subplot(gs[2, 1])
        stats.probplot(ic_5d, dist="norm", plot=ax4)
        ax4.set_title("5D Period IC Normal Dist. Q-Q")

    if len(ic_10d) > 1:
        ax5 = fig.add_subplot(gs[3, 0])
        ax5.hist(ic_10d, bins=40, alpha=0.7, density=True, color='skyblue', edgecolor='k')
        kde10d = stats.gaussian_kde(ic_10d)
        x10d = np.linspace(ic_10d.min(), ic_10d.max(), 200)
        ax5.plot(x10d, kde10d(x10d), color='blue')
        ax5.set_title(f"10D Period IC\nMean {mean10d:.3f}   Std. {std10d:.3f}")
        ax5.set_xlabel("IC")

        ax6 = fig.add_subplot(gs[3, 1])
        stats.probplot(ic_10d, dist="norm", plot=ax6)
        ax6.set_title("10D Period IC Normal Dist. Q-Q")

    if len(ic_5d) > 0:
        ax7 = fig.add_subplot(gs[4, 0])
        ic_5d_month = ic_5d.groupby([ic_5d.index.year, ic_5d.index.month]).mean().unstack()
        im7 = ax7.imshow(ic_5d_month, aspect='auto', cmap='coolwarm', vmin=-0.2, vmax=0.2)
        for (i_idx, j_idx), val in np.ndenumerate(ic_5d_month.values):  # Use .values for ndenumerate
            if pd.notnull(val): ax7.text(j_idx, i_idx, f"{val:.2f}", ha='center', va='center', fontsize=8)
        ax7.set_title("Monthly Mean 5D Period IC")
        ax7.set_xlabel("Month")
        ax7.set_ylabel("Year")
        ax7.set_xticks(np.arange(ic_5d_month.shape[1]))
        ax7.set_xticklabels(ic_5d_month.columns)  # Use actual month numbers from columns
        ax7.set_yticks(np.arange(ic_5d_month.shape[0]))
        ax7.set_yticklabels(ic_5d_month.index)

    if len(ic_10d) > 0:
        ax8 = fig.add_subplot(gs[4, 1])
        ic_10d_month = ic_10d.groupby([ic_10d.index.year, ic_10d.index.month]).mean().unstack()
        im8 = ax8.imshow(ic_10d_month, aspect='auto', cmap='coolwarm', vmin=-0.2, vmax=0.2)
        for (i_idx, j_idx), val in np.ndenumerate(ic_10d_month.values):
            if pd.notnull(val): ax8.text(j_idx, i_idx, f"{val:.2f}", ha='center', va='center', fontsize=8)
        ax8.set_title("Monthly Mean 10D Period IC")
        ax8.set_xlabel("Month")
        ax8.set_ylabel("Year")
        ax8.set_xticks(np.arange(ic_10d_month.shape[1]))
        ax8.set_xticklabels(ic_10d_month.columns)
        ax8.set_yticks(np.arange(ic_10d_month.shape[0]))
        ax8.set_yticklabels(ic_10d_month.index)

    fig.tight_layout()
    add_current_figure_to_word(doc, caption="IC分析六联图")


def plot_quantile_return_4in1(clean_factor_data, doc):
    import matplotlib.dates as mdates
    mean_returns, std_returns = al.performance.mean_return_by_quantile(clean_factor_data)
    quantiles = mean_returns.index
    periods_list = ['5D', '10D']  # Renamed
    fig, axes = plt.subplots(4, 1, figsize=(10, 18), gridspec_kw={'height_ratios': [1, 1.2, 1.5, 1.5]})

    bar_width = 0.35
    x_indices = np.arange(len(quantiles))  # Renamed x to x_indices
    for idx, period_val in enumerate(periods_list):  # Renamed period to period_val
        offset = (idx - 0.5) * bar_width
        axes[0].bar(x_indices + offset, mean_returns[period_val] * 10000, width=bar_width, label=period_val)
    axes[0].set_xticks(x_indices)
    axes[0].set_xticklabels([str(q) for q in quantiles])
    axes[0].set_ylabel('Mean Return (bps)')
    axes[0].set_title("Mean Period Wise Return By Factor Quantile")
    axes[0].legend()
    axes[0].grid(alpha=0.3)

    quantile_returns_list = []  # Renamed
    for period_val in periods_list:
        for q_val in quantiles:  # Renamed q to q_val
            # Access forward returns directly (e.g., '5D' column from clean_factor_data)
            data = clean_factor_data[clean_factor_data['factor_quantile'] == q_val][period_val].dropna() * 10000
            quantile_returns_list.append(pd.DataFrame({
                'quantile': str(q_val),
                'period': period_val,
                'return': data
            }))
    if quantile_returns_list:  # Check if list is not empty
        quantile_returns_df = pd.concat(quantile_returns_list, ignore_index=True)  # Renamed
        sns.violinplot(data=quantile_returns_df, x='quantile', y='return', hue='period', split=True, ax=axes[1])
        axes[1].set_title('Period Wise Return By Factor Quantile')
        axes[1].set_ylabel('Return (bps)')
        axes[1].legend(title='forward_periods')
        axes[1].grid(alpha=0.3)

    for i, period_val in enumerate(periods_list):
        top = clean_factor_data[clean_factor_data['factor_quantile'] == quantiles.max()].groupby(level='date')[
                  period_val].mean() * 10000
        bottom = clean_factor_data[clean_factor_data['factor_quantile'] == quantiles.min()].groupby(level='date')[
                     period_val].mean() * 10000
        spread = top - bottom
        axes[2 + i].plot(spread.index, spread.values, alpha=0.5, label='mean returns spread')
        if len(spread) > 20:
            rolling = spread.rolling(window=20, min_periods=1).mean()
            axes[2 + i].plot(rolling.index, rolling.values, color='orangered', label='1 month moving avg')
        axes[2 + i].set_ylabel('Difference in Quantile Mean Return (bps)')
        axes[2 + i].set_title(f"Top Minus Bottom Quantile Mean Return ({period_val} Period Forward Return)")
        axes[2 + i].legend()
        axes[2 + i].grid(alpha=0.3)
        axes[2 + i].xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))  # Format x-axis dates
        axes[2 + i].tick_params(axis='x', rotation=15)

    plt.tight_layout()
    add_current_figure_to_word(doc, caption='分位收益分析四联图')


# ========== 业绩分析表&年度回撤图 ==========
def calc_excess_return_performance_table(clean_factor_data, period='5D'):
    columns = ['year', 'cumulative_excess_return', 'sharpe', 'max_drawdown', 'calmar', 'trading_days', 'turnover']
    df = clean_factor_data.reset_index()
    df['date'] = pd.to_datetime(df['date'])
    df['year'] = df['date'].dt.year
    results = []
    unique_years = sorted(df['year'].unique())

    for year_val in unique_years:
        dfy = df[df['year'] == year_val]
        daily_excess_return = dfy.groupby('date').apply(
            lambda x: x[x['factor_quantile'] == 5][period].mean() - x[x['factor_quantile'] == 1][period].mean()
        ).dropna()

        if len(daily_excess_return) == 0:
            results.append([year_val, np.nan, np.nan, np.nan, np.nan, 0, np.nan])
            continue

        num_trading_days = len(daily_excess_return)
        cumulative_return_for_period = (1 + daily_excess_return).prod() - 1

        geometric_annualized_return = np.nan
        if num_trading_days > 0:
            base_for_annualization = 1 + cumulative_return_for_period
            if base_for_annualization < 0: base_for_annualization = 0
            geometric_annualized_return = (base_for_annualization ** (252 / num_trading_days)) - 1

        annualized_volatility = daily_excess_return.std() * np.sqrt(252)
        sharpe = np.nan
        if annualized_volatility is not None and annualized_volatility > 1e-9 and pd.notnull(
                geometric_annualized_return):
            sharpe = geometric_annualized_return / annualized_volatility

        cum_net_value = (1 + daily_excess_return).cumprod()
        max_drawdown_value = ((cum_net_value / cum_net_value.cummax()) - 1).min()
        if not np.isfinite(max_drawdown_value): max_drawdown_value = np.nan

        calmar = np.nan
        if max_drawdown_value is not None and abs(max_drawdown_value) > 1e-9 and pd.notnull(
                geometric_annualized_return):
            calmar = geometric_annualized_return / abs(max_drawdown_value)

        turnover_value = dfy[dfy['factor_quantile'].isin([1, 5])].shape[
                             0] / num_trading_days if num_trading_days > 0 else np.nan

        results.append([
            year_val, cumulative_return_for_period, sharpe, max_drawdown_value, calmar,
            num_trading_days, round(turnover_value * 100, 2) if pd.notnull(turnover_value) else np.nan
        ])

    daily_excess_return_overall = df.groupby('date').apply(
        lambda x: x[x['factor_quantile'] == 5][period].mean() - x[x['factor_quantile'] == 1][period].mean()
    ).dropna()

    if len(daily_excess_return_overall) > 0:
        num_trading_days_overall = len(daily_excess_return_overall)
        cumulative_return_overall = (1 + daily_excess_return_overall).prod() - 1

        geometric_annualized_return_overall = np.nan
        if num_trading_days_overall > 0:
            base_overall_annualization = 1 + cumulative_return_overall
            if base_overall_annualization < 0: base_overall_annualization = 0
            geometric_annualized_return_overall = (base_overall_annualization ** (252 / num_trading_days_overall)) - 1

        annualized_volatility_overall = daily_excess_return_overall.std() * np.sqrt(252)
        sharpe_overall = np.nan
        if annualized_volatility_overall is not None and annualized_volatility_overall > 1e-9 and pd.notnull(
                geometric_annualized_return_overall):
            sharpe_overall = geometric_annualized_return_overall / annualized_volatility_overall

        cum_net_value_overall = (1 + daily_excess_return_overall).cumprod()
        max_drawdown_overall = ((cum_net_value_overall / cum_net_value_overall.cummax()) - 1).min()
        if not np.isfinite(max_drawdown_overall): max_drawdown_overall = np.nan

        calmar_overall = np.nan
        if max_drawdown_overall is not None and abs(max_drawdown_overall) > 1e-9 and pd.notnull(
                geometric_annualized_return_overall):
            calmar_overall = geometric_annualized_return_overall / abs(max_drawdown_overall)

        turnover_overall_value = df[df['factor_quantile'].isin([1, 5])].shape[
                                     0] / num_trading_days_overall if num_trading_days_overall > 0 else np.nan

        results.append([
            'Overall', cumulative_return_overall, sharpe_overall, max_drawdown_overall, calmar_overall,
            num_trading_days_overall,
            round(turnover_overall_value * 100, 2) if pd.notnull(turnover_overall_value) else np.nan
        ])
    else:
        results.append(['Overall', np.nan, np.nan, np.nan, np.nan, 0, np.nan])

    perf_df = pd.DataFrame(results, columns=columns)

    for col in ['cumulative_excess_return', 'max_drawdown']:
        perf_df[col] = perf_df[col].apply(lambda x: f"{x:.2%}" if pd.notnull(x) else 'N/A')
    for col in ['sharpe', 'calmar']:
        perf_df[col] = perf_df[col].apply(lambda x: f"{x:.2f}" if pd.notnull(x) else 'N/A')
    perf_df['trading_days'] = perf_df['trading_days'].astype(int)
    perf_df['turnover'] = perf_df['turnover'].apply(lambda x: f"{x:.2f}" if pd.notnull(x) else 'N/A')

    return perf_df


def plot_yearly_cum_return_drawdown(clean_factor_data, year, doc, period='5D'):  # Changed default to 5D to match table
    import matplotlib.dates as mdates  # Keep import here if only used here

    df = clean_factor_data.reset_index()
    df['year'] = df['date'].dt.year  # Ensure date is datetime before dt accessor
    dfy = df[df['year'] == year]
    if dfy.empty:
        print(f"{year}年无数据，跳过绘图。")
        return

    # Calculate daily returns using the 'period' argument
    daily = dfy.groupby('date').apply(
        lambda x: pd.Series({
            'strategy': x[x['factor_quantile'] == 5][period].mean(),  # Use passed 'period'
            'benchmark': x[x['factor_quantile'] == 1][period].mean(),  # Use passed 'period'
        })
    ).dropna()  # Drop rows where mean could not be computed (e.g. no stocks in quantile)

    if daily.empty:
        print(f"{year}年计算每日收益后无数据，跳过绘图。")
        return

    daily['excess'] = daily['strategy'] - daily['benchmark']
    # daily = daily.fillna(0) # Fill NA after calculating excess, or handle NA in cumprod

    # Calculate cumulative net values (starting from 1)
    cumret_strategy = (1 + daily['strategy']).cumprod()
    cumret_benchmark = (1 + daily['benchmark']).cumprod()
    cumret_excess = (1 + daily['excess']).cumprod()

    # Calculate drawdown for the strategy (as percentage)
    rollmax_strategy = cumret_strategy.cummax()
    drawdown_strategy_pct = (cumret_strategy / rollmax_strategy - 1) * 100  # Negative values
    abs_drawdown_strategy_pct = -drawdown_strategy_pct  # Positive values for plotting fill_between

    # Convert cumulative net values to percentage returns (from 0%)
    strategy_pct_return = (cumret_strategy - 1) * 100
    benchmark_pct_return = (cumret_benchmark - 1) * 100
    excess_pct_return = (cumret_excess - 1) * 100

    fig, ax1 = plt.subplots(figsize=(8, 4.5))
    ax2 = ax1.twinx()

    # Plot drawdown (absolute percentage)
    ax1.fill_between(abs_drawdown_strategy_pct.index, 0, abs_drawdown_strategy_pct.values, color='lightcoral',
                     alpha=0.5, step='mid', label='Strategy Drawdown')
    ax1.set_ylabel('Drawdown (%)', color='red')
    ax1.set_ylim(0, max(10, abs_drawdown_strategy_pct.max() * 1.2 if pd.notnull(
        abs_drawdown_strategy_pct.max()) else 10))  # Dynamic Ylim
    ax1.tick_params(axis='y', labelcolor='red')
    # ax1.legend(loc='lower left', fontsize=8) # Optional: legend for drawdown

    # Plot cumulative returns (percentage)
    ax2.plot(strategy_pct_return.index, strategy_pct_return.values, 'b-', label='Strategy Cumulative Return (%)',
             linewidth=1.5)
    ax2.plot(benchmark_pct_return.index, benchmark_pct_return.values, 'g--', label='Benchmark Cumulative Return (%)',
             linewidth=1.2)
    ax2.plot(excess_pct_return.index, excess_pct_return.values, 'orange', linestyle='-.',
             label='Excess Cumulative Return (%)', linewidth=1.2)
    ax2.set_ylabel('Cumulative Return (%)')
    ax2.tick_params(axis='y')
    ax2.legend(loc='upper left', fontsize=8)

    # Common settings
    plt.title(f"Cumulative Return and Drawdown for {year} (Period: {period})")
    ax1.xaxis.set_major_locator(
        mdates.MonthLocator(interval=max(1, len(daily.index) // (12 * 5))))  # Dynamic interval for months
    ax1.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
    plt.setp(ax1.xaxis.get_majorticklabels(), rotation=25, ha="right")
    fig.tight_layout()  # Use fig.tight_layout()

    add_current_figure_to_word(doc, caption=f'Cumulative Return and Drawdown for {year} (Period: {period})')


# ========== 主流程 ==========
def backtest_and_report(input_csv_path, factor_name, output_report_dir, start_date='2021-01-01', max_loss=0.85):
    print(f"【进度】读取含因子的csv: {input_csv_path}")
    try:
        df_raw = pd.read_csv(input_csv_path)
    except FileNotFoundError:
        print(f"【错误】文件未找到: {input_csv_path}")
        return

    print(f"【DEBUG】{factor_name} 原始数据行数: {len(df_raw)}")
    if factor_name not in df_raw.columns:
        print(f"【跳过】因子 '{factor_name}' 未在数据表的列中。可用列: {df_raw.columns.tolist()}")
        return

    print(f"【DEBUG】{factor_name} 非空比例：", df_raw[factor_name].notnull().mean())
    print(f"【DEBUG】{factor_name} 唯一值数量：", df_raw[factor_name].nunique())
    # print(f"【DEBUG】{factor_name} 前10个非空值：", df_raw[factor_name].dropna().head(10).tolist())

    df_raw['dateTime'] = pd.to_datetime(df_raw['dateTime'])
    df_raw = df_raw.sort_values(['securityId', 'dateTime'])

    # Reshape price data and filter by start_date AFTER reshaping
    price_df_full = reshape_price_data(df_raw.copy())  # Use a copy for reshaping
    price_df = price_df_full.loc[price_df_full.index >= pd.to_datetime(start_date)]
    if price_df.empty:
        print(f"【跳过】价格数据在 {start_date} 之后为空。")
        return

    os.makedirs(output_report_dir, exist_ok=True)

    df_fac_raw = df_raw[['dateTime', 'securityId', factor_name]].copy()  # Use .copy()
    df_fac_raw.rename(columns={factor_name: 'factor', 'dateTime': 'date', 'securityId': 'asset'}, inplace=True)
    df_fac_raw.dropna(subset=['factor'], inplace=True)

    if df_fac_raw.empty:
        print(f"【跳过】因子 '{factor_name}' 数据在去除NaN后为空。")
        return

    print(f"  [Alphalens清洗] {factor_name} ...")
    df_fac_indexed = df_fac_raw.set_index(['date', 'asset']).sort_index()

    # Filter factor data based on price_df's date range to avoid issues with alphalens
    min_price_date, max_price_date = price_df.index.min(), price_df.index.max()
    df_fac_indexed = df_fac_indexed.loc[(df_fac_indexed.index.get_level_values('date') >= min_price_date) & \
                                        (df_fac_indexed.index.get_level_values('date') <= max_price_date)]

    if df_fac_indexed.empty:
        print(f"【跳过】因子 '{factor_name}' 数据在价格日期范围内过滤后为空。")
        return

    print('【调试】因子每期唯一值数量描述：')
    print(df_fac_indexed.reset_index().groupby('date')['factor'].nunique().describe())
    # print('【调试】部分日期唯一值明细（前20期）：')
    # print(df_fac_indexed.reset_index().groupby('date')['factor'].nunique().head(20))

    try:
        clean_factor_data = al.utils.get_clean_factor_and_forward_returns(
            factor=df_fac_indexed['factor'],  # Pass Series
            prices=price_df,
            periods=[1, 5, 10],  # Ensure these are used by Alphalens
            quantiles=5,
            max_loss=max_loss,
        )
    except Exception as e:
        print(f"  [跳过] {factor_name} Alphalens报错: {e}")
        import traceback
        traceback.print_exc()
        return

    if clean_factor_data.empty:
        print(f"【跳过】{factor_name} clean_factor_data 为空。")
        return

    print(f"[{factor_name}] clean_factor_data.head():")
    print(clean_factor_data.head())

    output_path = os.path.join(output_report_dir, f"factor_analysis_report_{factor_name}.docx")
    if os.path.exists(output_path):
        try:
            os.remove(output_path)
        except PermissionError:
            print(f"【警告】无法删除现有报告 {output_path}，可能文件正被打开。将尝试使用带时间戳的文件名。")
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            output_path = os.path.join(output_report_dir, f"factor_analysis_report_{factor_name}_{timestamp}.docx")

    doc = Document()
    doc.add_heading(f'因子分析报告：{factor_name}', level=0)
    current_time_str = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')  # Explicitly UTC
    doc.add_paragraph(f'生成时间: {current_time_str}\n')

    mean_returns, std_returns = al.performance.mean_return_by_quantile(clean_factor_data)
    quantile_mean_df = mean_returns.reset_index().rename(columns={"factor_quantile": "quantile"})
    quantile_std_df = std_returns.reset_index().rename(columns={"factor_quantile": "quantile"})

    # Ensure correct prefixing for merge
    mean_cols = [col for col in quantile_mean_df.columns if col != 'quantile']
    std_cols = [col for col in quantile_std_df.columns if col != 'quantile']

    quantile_mean_df_prefixed = quantile_mean_df[['quantile'] + mean_cols].add_prefix('mean_')
    quantile_std_df_prefixed = quantile_std_df[['quantile'] + std_cols].add_prefix('std_')

    quantile_df = pd.merge(
        quantile_mean_df_prefixed.rename(columns={'mean_quantile': 'quantile'}),
        quantile_std_df_prefixed.rename(columns={'std_quantile': 'quantile'}),
        on='quantile'
    )
    for period_val in ['1D', '5D', '10D']:  # Use period_val
        if f'mean_{period_val}' in quantile_df.columns:
            quantile_df[f'mean_{period_val}'] = (quantile_df[f'mean_{period_val}'] * 10000).round(2)
        if f'std_{period_val}' in quantile_df.columns:
            quantile_df[f'std_{period_val}'] = (quantile_df[f'std_{period_val}'] * 10000).round(2)
    quantile_df['quantile'] = quantile_df['quantile'].astype('str')

    ic_series = al.performance.factor_information_coefficient(clean_factor_data)
    ic_df_data = {
        'IC_mean': ic_series.mean(),
        'IC_std': ic_series.std(),
    }
    # Calculate IR only if std is not zero or very small
    ir_ratio = {}
    for col in ic_series.columns:
        mean_ic = ic_series[col].mean()
        std_ic = ic_series[col].std()
        if pd.notnull(std_ic) and std_ic > 1e-9:
            ir_ratio[col] = mean_ic / std_ic
        else:
            ir_ratio[col] = np.nan

    ic_df_data['IR Ratio'] = pd.Series(ir_ratio)
    ic_df = pd.DataFrame(ic_df_data, index=ic_series.columns).T.rename_axis('Metric', axis=0).rename_axis('Period',
                                                                                                          axis=1)  # Adjusted
    ic_df = ic_df.reset_index()  # Metric becomes a column
    for period_val in ['1D', '5D', '10D']:
        if period_val in ic_df.columns:
            ic_df[period_val] = ic_df[period_val].round(3)

    turnover_df = calculate_turnover_metrics(clean_factor_data.copy())  # Pass a copy

    dataframe_to_word(quantile_df, doc, title="Return Analysis (bps)")
    dataframe_to_word(ic_df, doc, title="IC Analysis")
    dataframe_to_word(turnover_df, doc, title="Turnover Analysis (%)")

    plot_quantile_return_4in1(clean_factor_data, doc)
    plot_ic_and_distribution(clean_factor_data, doc)
    plot_turnover_and_rank_autocorr(clean_factor_data, doc)

    # Use '5D' for the main performance table as per original logic
    perf_df = calc_excess_return_performance_table(clean_factor_data, period='5D')
    dataframe_to_word(perf_df, doc, title="Excess-return Performance (Based on 5D forward returns)")

    years = sorted(clean_factor_data.reset_index()['date'].dt.year.unique())
    for year_val in years:
        # Plot yearly returns using the same period as the table for consistency in this section
        plot_yearly_cum_return_drawdown(clean_factor_data, year_val, doc, period='5D')

    doc.save(output_path)
    print(f"  [完成] {factor_name} 分析报告已保存: {output_path}")


# ========== 主入口 ==========
if __name__ == '__main__':
    # 使用相对路径或确保这些目录存在
    script_dir = os.path.dirname(os.path.abspath(__file__)) if '__file__' in locals() else '.'
    factor_csv_dir = os.path.join(script_dir, 'csvs')
    output_report_dir = os.path.join(script_dir, 'reports')

    # 创建示例目录（如果它们不存在）
    os.makedirs(factor_csv_dir, exist_ok=True)
    os.makedirs(output_report_dir, exist_ok=True)

    # === 生成一个虚拟的CSV文件用于测试 ===
    sample_factor_name = '尾部贝塔'
    sample_csv_path = os.path.join(factor_csv_dir, f'量价_{sample_factor_name}.csv')

    if not os.path.exists(sample_csv_path):
        print(f"生成示例CSV文件: {sample_csv_path}")
        num_assets = 50
        date_rng = pd.date_range(start='2019-12-01', end='2023-12-31', freq='B')
        sample_data_list = []
        for dt in date_rng:
            for i in range(num_assets):
                asset_id = f'stock_{i:03d}'
                sample_data_list.append({
                    'dateTime': dt,
                    'securityId': asset_id,
                    'close': np.random.uniform(10, 100) * (1 + np.random.normal(0, 0.02)),  # Price with some trend
                    sample_factor_name: np.random.normal(0, 1)  # Factor values
                })
        sample_df = pd.DataFrame(sample_data_list)
        # Introduce some NaNs into the factor
        nan_indices = np.random.choice(sample_df.index, size=int(0.05 * len(sample_df)), replace=False)
        sample_df.loc[nan_indices, sample_factor_name] = np.nan
        sample_df.to_csv(sample_csv_path, index=False)
        print("示例CSV文件生成完毕。")
    # =======================================

    factor_names = [sample_factor_name]  # Test with the sample factor

    for factor_name_iter in factor_names:  # Renamed factor_name to avoid conflict
        input_csv_path = os.path.join(factor_csv_dir, f'量价_{factor_name_iter}.csv')
        if not os.path.exists(input_csv_path):
            print(f"【警告】未找到因子CSV文件: {input_csv_path}。请确保文件存在于 'csvs' 目录下。")
            continue

        backtest_and_report(
            input_csv_path=input_csv_path,
            factor_name=factor_name_iter,
            output_report_dir=output_report_dir,
            start_date='2020-01-01',  # Start date for analysis
            max_loss=0.99  # Alphalens max_loss parameter
        )