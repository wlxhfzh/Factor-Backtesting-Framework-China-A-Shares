import pandas as pd
import os
import glob
from tqdm import tqdm
from datetime import datetime
import concurrent.futures
import psutil
import time


def is_trading_time(time):
    """判断是否为交易时间"""
    hour, minute = time.hour, time.minute
    # 上午交易时段：9:30-11:30
    if (9 < hour < 11) or (hour == 9 and minute >= 30) or (hour == 11 and minute <= 30):
        return True
    # 下午交易时段：13:00-15:00
    if 13 <= hour <= 15:
        return True
    return False

import pandas as pd

def resample_klines(df, period="60min", date_str=''):
    """
    修正K线合成错误，支持10分钟、30分钟、60分钟
    period 可选：'10min', '30min', '60min'
    """
    if not isinstance(df.index, pd.MultiIndex):
        raise ValueError("输入数据必须是双索引(dateTime, securityId)格式")

    if df.index.names != ['dateTime', 'securityId']:
        raise ValueError(f"索引名必须是['dateTime', 'securityId']，当前是{df.index.names}")

    def resample_group(group_df):
        group_df = group_df.reset_index(level='securityId')
        group_df.index = pd.to_datetime(group_df.index)

        # 交易时间筛选，防止出现12:30等错误时间
        morning_df = group_df.between_time("09:30", "11:30")
        afternoon_df = group_df.between_time("13:00", "15:00")

        # 计算成交额 turnover（VWAP * volume）
        for df_part in [morning_df, afternoon_df]:
            df_part["turnover"] = df_part["volume"] * df_part["vwap"]

        # **定义不同K线级别的时间区间**
        time_ranges_dict = {
            "10min": [("09:30", "09:40"), ("09:40", "09:50"), ("09:50", "10:00"),
                      ("10:00", "10:10"), ("10:10", "10:20"), ("10:20", "10:30"),
                      ("10:30", "10:40"), ("10:40", "10:50"), ("10:50", "11:00"),
                      ("11:00", "11:10"), ("11:10", "11:20"), ("11:20", "11:30"),
                      ("13:00", "13:10"), ("13:10", "13:20"), ("13:20", "13:30"),
                      ("13:30", "13:40"), ("13:40", "13:50"), ("13:50", "14:00"),
                      ("14:00", "14:10"), ("14:10", "14:20"), ("14:20", "14:30"),
                      ("14:30", "14:40"), ("14:40", "14:50"), ("14:50", "15:00")],
            "30min": [("09:30", "10:00"), ("10:00", "10:30"), ("10:30", "11:00"), ("11:00", "11:30"),
                      ("13:00", "13:30"), ("13:30", "14:00"), ("14:00", "14:30"), ("14:30", "15:00")],
            "60min": [("09:30", "10:30"), ("10:30", "11:30"),
                      ("13:00", "14:00"), ("14:00", "15:00")]
        }

        if period not in time_ranges_dict:
            raise ValueError("period 只能是 '10min', '30min', '60min' 之一")

        time_ranges = time_ranges_dict[period]

        # **按照时间区间进行K线合成**
        def resample_fixed(df_part, time_ranges):
            kline_list = []
            for start, end in time_ranges:
                # 取出第一行的日期
                current_date = df_part.index[0].date()

                # 将传入的 start 和 end（例如 "09:30" 和 "10:30"）与该日期拼接成完整的 datetime
                start_datetime = pd.to_datetime(f"{current_date} {start}")
                end_datetime = pd.to_datetime(f"{current_date} {end}")

                # 使用完整 datetime 比较，实现左开右闭（不包含 start_datetime，包含 end_datetime）
                kline = df_part[(df_part.index > start_datetime) & (df_part.index <= end_datetime)]
                if not kline.empty:
                    resampled = {
                        "open": kline["open"].iloc[0],
                        "high": kline["high"].max(),
                        "low": kline["low"].min(),
                        "close": kline["close"].iloc[-1],
                        "volume": kline["volume"].sum(),
                        "amount": kline["amount"].sum(),
                        "turnover": kline["turnover"].sum(),
                        "securityId": kline["securityId"].iloc[0]
                    }
                    kline_list.append(pd.DataFrame(resampled, index=[end]))  # 以结束时间为索引
            return pd.concat(kline_list) if kline_list else pd.DataFrame()

        morning_resampled = resample_fixed(morning_df, time_ranges)
        afternoon_resampled = resample_fixed(afternoon_df, time_ranges)

        # 计算 VWAP
        for df_resampled in [morning_resampled, afternoon_resampled]:
            df_resampled["vwap"] = df_resampled["turnover"] / df_resampled["volume"]
            df_resampled.drop(columns=["turnover"], inplace=True)

        # **最终合并**
        resampled = pd.concat([morning_resampled, afternoon_resampled]).sort_index()


        # 重新设定索引
        resampled = resampled.set_index("securityId", append=True)
        resampled.index.names = ["dateTime", "securityId"]

        return resampled

    result = df.groupby(level="securityId").apply(resample_group)

    if isinstance(result.index, pd.MultiIndex) and len(result.index.names) > 2:
        result = result.droplevel(0)

    result_reset = result.reset_index(level='dateTime')
    result_reset['newDateTime'] = pd.to_datetime(date_str + ' ' + result_reset['dateTime'].astype(str))

    result_reset = result_reset.reset_index()  # 将原先的 securityId 也转为普通列
    result_new = result_reset.set_index(['newDateTime', 'securityId'])
    result_new.index.names = ['dateTime', 'securityId']

    return result_new


def process_single_file(file, output_folder, period):
    """
    处理单个文件，返回文件日期（字符串）及错误信息（None 表示成功）
    """
    try:
        base = os.path.basename(file)
        file_date_str = base.replace('.pkl', '')
        # 输出当前文件处理提示
        # print(f"处理日期 {file_date_str} 的数据...")

        df = pd.read_pickle(file)
        df_resampled = resample_klines(df, period=period, date_str=file_date_str)
        out_file = os.path.join(output_folder, f"{file_date_str}.pkl")
        df_resampled.to_pickle(out_file)
        return file_date_str, None
    except Exception as e:
        return file, str(e)


def process_files(input_folder, output_folder, period, start_date=None, end_date=None, max_workers=4):
    """
    扫描 input_folder 下所有 .pkl 文件，
    根据文件名（格式 "YYYY-MM-DD.pkl"）进行日期过滤，
    仅处理指定日期区间的文件，
    多线程处理后保存结果到 output_folder 中，
    同时输出内存使用情况和进度提示。
    """
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    file_list = glob.glob(os.path.join(input_folder, '*.pkl'))
    if not file_list:
        print("未找到任何 .pkl 文件！")
        return

    # 日期筛选：从文件名中解析日期（格式 "YYYY-MM-DD.pkl"）
    filtered_files = []
    if start_date:
        start_dt = datetime.strptime(start_date, "%Y-%m-%d")
    else:
        start_dt = None
    if end_date:
        end_dt = datetime.strptime(end_date, "%Y-%m-%d")
    else:
        end_dt = None

    for file in file_list:
        base = os.path.basename(file)
        file_date_str = base.replace('.pkl', '')
        try:
            file_date = datetime.strptime(file_date_str, "%Y-%m-%d")
        except Exception:
            print(f"无法解析文件 {base} 的日期，跳过。")
            continue
        if start_dt and file_date < start_dt:
            continue
        if end_dt and file_date > end_dt:
            continue
        filtered_files.append(file)

    if not filtered_files:
        print("没有符合日期范围的文件！")
        return

    print(f"共找到 {len(filtered_files)} 个符合条件的文件，开始处理...")

    # 使用 ThreadPoolExecutor 并结合 tqdm 显示进度
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        # 提交任务
        future_to_file = {executor.submit(process_single_file, file, output_folder, period): file for file in
                          filtered_files}
        for future in tqdm(concurrent.futures.as_completed(future_to_file), total=len(future_to_file),
                           desc="Processing files"):
            res = future.result()
            results.append(res)
            # 输出当前内存使用情况（单位：MB）
            mem = psutil.virtual_memory()
            print(f"当前内存使用：{mem.used / 1024 / 1024:.1f} MB / {mem.total / 1024 / 1024:.1f} MB")

    # 输出处理结果
    for item in results:
        file_id, err = item
        if err is None:
            print(f"文件 {file_id} 处理成功。")
        else:
            print(f"文件 {file_id} 处理失败，错误信息：{err}")


# 使用示例
if __name__ == "__main__":
    # 读取5分钟K线数据
    input_folder = '/Volumes/Elements/hb_data/intraday_cbond_quota/minute_5'
    output_folder = '/Volumes/Elements/hb_data/intraday_cbond_quota/minute_30'  # 请替换为您的输出路径
    period = '30min'  # 可选 '10min', '30min', '60min'
    start_date = "2021-01-01"  # 可选
    end_date = "2025-02-28"  # 可选
    max_workers = 2  # 可选

    process_files(input_folder, output_folder, period, start_date, end_date, max_workers)